export interface GenerationRequest {
  personImageKey: string;
  garmentImageKey: string;
  productCategory: string;
  productVariant?: string;
  color?: string;
  measurements?: Record<string, number>;
  fitPreference?: string;
}

export interface GenerationResult {
  imageKey: string;
  imageUrl: string;
  qualityScore: number;
  productFidelityScore: number;
  identityPreservationScore: number;
  warnings: string[];
  generationTimeMs: number;
}

export interface ProviderAdapter {
  name: string;
  supportedCategories: string[];
  estimatedCostPerGeneration: number;
  expectedGenerationTimeMs: number;
  qualityRating: number;
  generate(request: GenerationRequest): Promise<GenerationResult>;
  healthCheck(): Promise<boolean>;
}
