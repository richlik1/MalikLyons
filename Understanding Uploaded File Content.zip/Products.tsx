import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Search, Plus, Pencil, Trash2, Wand2, Upload, Filter } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface Product {
  id: number;
  name: string;
  vendor: string;
  price: string;
  category: string;
  variants: number;
  tryOnEnabled: boolean;
  emoji: string;
  description: string;
}

const INITIAL_PRODUCTS: Product[] = [
  { id: 1,  name: "Silk Wrap Dress",       vendor: "Lumière",  price: "$189", category: "Dresses",   variants: 5, tryOnEnabled: true,  emoji: "👗", description: "Elegant silk wrap dress with adjustable tie waist." },
  { id: 2,  name: "Linen Blazer",          vendor: "Lumière",  price: "$245", category: "Outerwear", variants: 4, tryOnEnabled: true,  emoji: "🧥", description: "Tailored linen blazer, perfect for smart-casual occasions." },
  { id: 3,  name: "Cashmere Sweater",      vendor: "Lumière",  price: "$165", category: "Tops",      variants: 6, tryOnEnabled: false, emoji: "🧶", description: "Luxuriously soft cashmere crew-neck sweater." },
  { id: 4,  name: "Wide-Leg Trousers",     vendor: "Lumière",  price: "$135", category: "Bottoms",   variants: 4, tryOnEnabled: true,  emoji: "👖", description: "High-waisted wide-leg trousers in premium fabric." },
  { id: 5,  name: "Knit Cardigan",         vendor: "Lumière",  price: "$120", category: "Tops",      variants: 5, tryOnEnabled: false, emoji: "🧣", description: "Relaxed-fit knit cardigan with button closure." },
  { id: 6,  name: "Floral Midi Skirt",     vendor: "Lumière",  price: "$98",  category: "Bottoms",   variants: 3, tryOnEnabled: true,  emoji: "👘", description: "Flowing floral print midi skirt with elastic waist." },
  { id: 7,  name: "Satin Slip Dress",      vendor: "Lumière",  price: "$210", category: "Dresses",   variants: 4, tryOnEnabled: true,  emoji: "👗", description: "Minimalist satin slip dress for evening wear." },
  { id: 8,  name: "Cropped Trench Coat",   vendor: "Lumière",  price: "$320", category: "Outerwear", variants: 3, tryOnEnabled: false, emoji: "🧥", description: "Classic cropped trench coat in water-resistant cotton." },
  { id: 9,  name: "Ribbed Turtleneck",     vendor: "Lumière",  price: "$89",  category: "Tops",      variants: 7, tryOnEnabled: true,  emoji: "👕", description: "Slim-fit ribbed turtleneck in stretch jersey." },
  { id: 10, name: "Pleated Midi Dress",    vendor: "Lumière",  price: "$175", category: "Dresses",   variants: 4, tryOnEnabled: false, emoji: "👗", description: "Elegant pleated midi dress with V-neckline." },
  { id: 11, name: "Tailored Shorts",       vendor: "Lumière",  price: "$95",  category: "Bottoms",   variants: 4, tryOnEnabled: false, emoji: "🩳", description: "High-waisted tailored shorts in linen blend." },
  { id: 12, name: "Oversized Shirt",       vendor: "Lumière",  price: "$110", category: "Tops",      variants: 5, tryOnEnabled: true,  emoji: "👔", description: "Relaxed oversized shirt in organic cotton poplin." },
];

const CATEGORIES = ["All", "Dresses", "Tops", "Bottoms", "Outerwear"];

export default function Products() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [newProduct, setNewProduct] = useState({ name: "", price: "", category: "Tops", description: "" });
  const [selected, setSelected] = useState<number[]>([]);

  const filtered = products.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchCat = category === "All" || p.category === category;
    return matchSearch && matchCat;
  });

  const toggleTryOn = (id: number) => {
    setProducts((prev) => prev.map((p) => p.id === id ? { ...p, tryOnEnabled: !p.tryOnEnabled } : p));
    toast.success("Try-on status updated");
  };

  const handleDelete = (id: number) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    setDeleteId(null);
    toast.success("Product deleted");
  };

  const handleSaveEdit = () => {
    if (!editProduct) return;
    setProducts((prev) => prev.map((p) => p.id === editProduct.id ? editProduct : p));
    setEditProduct(null);
    toast.success("Product updated");
  };

  const handleAddProduct = () => {
    if (!newProduct.name.trim()) return;
    const id = Math.max(...products.map((p) => p.id)) + 1;
    setProducts((prev) => [...prev, {
      id,
      name: newProduct.name,
      vendor: "Lumière",
      price: newProduct.price || "$0",
      category: newProduct.category,
      variants: 1,
      tryOnEnabled: false,
      emoji: "👗",
      description: newProduct.description,
    }]);
    setNewProduct({ name: "", price: "", category: "Tops", description: "" });
    setAddOpen(false);
    toast.success("Product added");
  };

  const bulkToggle = (enable: boolean) => {
    setProducts((prev) => prev.map((p) => selected.includes(p.id) ? { ...p, tryOnEnabled: enable } : p));
    setSelected([]);
    toast.success(`Try-on ${enable ? "enabled" : "disabled"} for ${selected.length} products`);
  };

  const toggleSelect = (id: number) => {
    setSelected((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]);
  };

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-serif text-3xl font-light text-white">Products</h1>
          <p className="text-sm text-[var(--color-ts-muted)] mt-1">{products.length} products in your catalog</p>
        </div>
        <Button
          onClick={() => setAddOpen(true)}
          className="bg-gradient-brand text-white hover:opacity-90 shadow-glow-blue"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Product
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-ts-muted)]" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search products…"
            className="pl-9 bg-[var(--color-ts-surface)] border-[var(--color-ts-border)] text-white placeholder:text-[var(--color-ts-muted-2)]"
          />
        </div>
        <div className="flex gap-1.5">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={cn(
                "px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
                category === c
                  ? "bg-[var(--color-ts-blue)]/15 text-[var(--color-ts-blue-light)] border border-[var(--color-ts-blue)]/20"
                  : "text-[var(--color-ts-muted)] hover:text-white border border-transparent"
              )}
            >
              {c}
            </button>
          ))}
        </div>
        {selected.length > 0 && (
          <div className="flex items-center gap-2 ml-auto">
            <span className="text-xs text-[var(--color-ts-muted)]">{selected.length} selected</span>
            <Button size="sm" variant="outline" onClick={() => bulkToggle(true)} className="text-xs border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:text-white">
              Enable Try-On
            </Button>
            <Button size="sm" variant="outline" onClick={() => bulkToggle(false)} className="text-xs border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:text-white">
              Disable
            </Button>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl overflow-hidden shadow-card">
        <div className="grid grid-cols-[auto_1fr_auto_auto_auto_auto_auto] gap-0 text-xs text-[var(--color-ts-muted)] border-b border-[var(--color-ts-border)] px-4 py-3">
          <div className="w-8" />
          <div>Product</div>
          <div className="w-24 text-center">Category</div>
          <div className="w-20 text-center">Price</div>
          <div className="w-20 text-center">Variants</div>
          <div className="w-24 text-center">Try-On</div>
          <div className="w-20 text-center">Actions</div>
        </div>
        {filtered.length === 0 ? (
          <div className="py-16 text-center text-[var(--color-ts-muted)] text-sm">No products found</div>
        ) : (
          filtered.map((p) => (
            <div
              key={p.id}
              className="grid grid-cols-[auto_1fr_auto_auto_auto_auto_auto] gap-0 items-center px-4 py-3.5 border-b border-[var(--color-ts-border)]/50 last:border-0 hover:bg-[var(--color-ts-surface-2)] transition-colors"
            >
              <div className="w-8">
                <input
                  type="checkbox"
                  checked={selected.includes(p.id)}
                  onChange={() => toggleSelect(p.id)}
                  className="w-3.5 h-3.5 rounded accent-[var(--color-ts-blue)]"
                />
              </div>
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-lg bg-[var(--color-ts-surface-2)] flex items-center justify-center text-lg shrink-0 border border-[var(--color-ts-border)]">
                  {p.emoji}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-medium text-white truncate">{p.name}</div>
                  <div className="text-xs text-[var(--color-ts-muted)]">{p.vendor}</div>
                </div>
              </div>
              <div className="w-24 text-center">
                <Badge className="text-xs bg-[var(--color-ts-surface-2)] text-[var(--color-ts-muted)] border-[var(--color-ts-border)]">
                  {p.category}
                </Badge>
              </div>
              <div className="w-20 text-center text-sm text-white">{p.price}</div>
              <div className="w-20 text-center text-sm text-[var(--color-ts-muted)]">{p.variants}</div>
              <div className="w-24 flex justify-center">
                <Switch
                  checked={p.tryOnEnabled}
                  onCheckedChange={() => toggleTryOn(p.id)}
                  className="data-[state=checked]:bg-[var(--color-ts-blue)]"
                />
              </div>
              <div className="w-20 flex items-center justify-center gap-1">
                <button
                  onClick={() => setEditProduct({ ...p })}
                  className="p-1.5 rounded-lg text-[var(--color-ts-muted)] hover:text-white hover:bg-[var(--color-ts-surface-3)] transition-colors"
                >
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setDeleteId(p.id)}
                  className="p-1.5 rounded-lg text-[var(--color-ts-muted)] hover:text-red-400 hover:bg-red-500/10 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Product Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="bg-[var(--color-ts-surface)] border-[var(--color-ts-border)] text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif text-xl font-medium">Add Product</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div>
              <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Product Name</Label>
              <Input
                value={newProduct.name}
                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                placeholder="e.g. Silk Wrap Dress"
                className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Price</Label>
                <Input
                  value={newProduct.price}
                  onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                  placeholder="$0.00"
                  className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white"
                />
              </div>
              <div>
                <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Category</Label>
                <Select value={newProduct.category} onValueChange={(v) => setNewProduct({ ...newProduct, category: v })}>
                  <SelectTrigger className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)]">
                    {["Dresses", "Tops", "Bottoms", "Outerwear"].map((c) => (
                      <SelectItem key={c} value={c} className="text-white">{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Description</Label>
              <Textarea
                value={newProduct.description}
                onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                placeholder="Brief product description…"
                className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white resize-none"
                rows={3}
              />
            </div>
            <div>
              <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Product Image</Label>
              <div className="border-2 border-dashed border-[var(--color-ts-border)] rounded-xl p-6 text-center cursor-pointer hover:border-[var(--color-ts-blue)]/40 transition-colors">
                <Upload className="w-6 h-6 text-[var(--color-ts-muted)] mx-auto mb-2" />
                <p className="text-xs text-[var(--color-ts-muted)]">Click to upload or drag & drop</p>
                <p className="text-[10px] text-[var(--color-ts-muted-2)] mt-1">PNG, JPG up to 10MB</p>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setAddOpen(false)} className="text-[var(--color-ts-muted)]">Cancel</Button>
            <Button onClick={handleAddProduct} className="bg-gradient-brand text-white hover:opacity-90">Add Product</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      {editProduct && (
        <Dialog open={!!editProduct} onOpenChange={() => setEditProduct(null)}>
          <DialogContent className="bg-[var(--color-ts-surface)] border-[var(--color-ts-border)] text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="font-serif text-xl font-medium">Edit Product</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div>
                <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Product Name</Label>
                <Input
                  value={editProduct.name}
                  onChange={(e) => setEditProduct({ ...editProduct, name: e.target.value })}
                  className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Price</Label>
                  <Input
                    value={editProduct.price}
                    onChange={(e) => setEditProduct({ ...editProduct, price: e.target.value })}
                    className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white"
                  />
                </div>
                <div>
                  <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Category</Label>
                  <Select value={editProduct.category} onValueChange={(v) => setEditProduct({ ...editProduct, category: v })}>
                    <SelectTrigger className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)]">
                      {["Dresses", "Tops", "Bottoms", "Outerwear"].map((c) => (
                        <SelectItem key={c} value={c} className="text-white">{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Description</Label>
                <Textarea
                  value={editProduct.description}
                  onChange={(e) => setEditProduct({ ...editProduct, description: e.target.value })}
                  className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white resize-none"
                  rows={3}
                />
              </div>
              <div className="flex items-center gap-3">
                <Switch
                  checked={editProduct.tryOnEnabled}
                  onCheckedChange={(v) => setEditProduct({ ...editProduct, tryOnEnabled: v })}
                  className="data-[state=checked]:bg-[var(--color-ts-blue)]"
                />
                <Label className="text-sm text-[var(--color-ts-muted)]">Try-On Enabled</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setEditProduct(null)} className="text-[var(--color-ts-muted)]">Cancel</Button>
              <Button onClick={handleSaveEdit} className="bg-gradient-brand text-white hover:opacity-90">Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Confirm */}
      <AlertDialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[var(--color-ts-surface)] border-[var(--color-ts-border)]">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white font-serif">Delete product?</AlertDialogTitle>
            <AlertDialogDescription className="text-[var(--color-ts-muted)]">
              This action cannot be undone. The product and its try-on configuration will be permanently removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[var(--color-ts-border)] text-[var(--color-ts-muted)]">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId !== null && handleDelete(deleteId)}
              className="bg-red-500/80 hover:bg-red-500 text-white border-0"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
