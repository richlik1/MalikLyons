import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  LayoutDashboard,
  Package,
  Wand2,
  Sliders,
  BarChart3,
  Plug,
  Menu,
  X,
  LogOut,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href: "/dashboard",              label: "Overview",     icon: LayoutDashboard },
  { href: "/dashboard/products",     label: "Products",     icon: Package },
  { href: "/dashboard/studio",       label: "Try-On Studio",icon: Wand2 },
  { href: "/dashboard/widget",       label: "Widget",       icon: Sliders },
  { href: "/dashboard/analytics",    label: "Analytics",    icon: BarChart3 },
  { href: "/dashboard/integrations", label: "Integrations", icon: Plug },
];

export default function DashboardShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout } = useAuth();

  const initials = user?.name
    ? user.name.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2)
    : "M";

  return (
    <div className="flex h-screen bg-[var(--color-background)] overflow-hidden">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 flex flex-col bg-[var(--color-ts-surface)] border-r border-[var(--color-ts-border)]",
          "transition-transform duration-300 ease-[var(--ease-out-snappy)]",
          "lg:relative lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo */}
        <div className="flex items-center justify-between h-16 px-6 border-b border-[var(--color-ts-border)]">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-7 h-7 rounded-lg bg-gradient-brand flex items-center justify-center shadow-glow-blue">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-serif text-lg font-semibold text-[var(--color-foreground)] tracking-tight">
              Trendset
            </span>
          </Link>
          <button
            className="lg:hidden text-[var(--color-ts-muted)] hover:text-[var(--color-foreground)] transition-colors"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
            const active = location === href || (href !== "/dashboard" && location.startsWith(href));
            return (
              <Link key={href} href={href}>
                <div
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 cursor-pointer group",
                    active
                      ? "bg-[var(--color-ts-blue)]/15 text-[var(--color-ts-blue-light)] border border-[var(--color-ts-blue)]/20"
                      : "text-[var(--color-ts-muted)] hover:text-[var(--color-foreground)] hover:bg-[var(--color-ts-surface-2)]"
                  )}
                >
                  <Icon className={cn("w-4 h-4 shrink-0", active ? "text-[var(--color-ts-blue)]" : "")} />
                  <span>{label}</span>
                  {active && <ChevronRight className="w-3 h-3 ml-auto opacity-60" />}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* User profile */}
        <div className="p-3 border-t border-[var(--color-ts-border)]">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-[var(--color-ts-surface-2)] transition-colors text-left">
                <Avatar className="w-8 h-8 shrink-0">
                  <AvatarFallback className="bg-gradient-brand text-white text-xs font-semibold">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[var(--color-foreground)] truncate">
                    {user?.name ?? "Merchant"}
                  </p>
                  <p className="text-xs text-[var(--color-ts-muted)] truncate">
                    {user?.email ?? "demo@trendset.io"}
                  </p>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)]">
              <DropdownMenuSeparator className="bg-[var(--color-ts-border)]" />
              <DropdownMenuItem
                onClick={logout}
                className="text-[var(--color-ts-muted)] hover:text-[var(--color-foreground)] cursor-pointer"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-16 flex items-center justify-between px-4 lg:px-6 border-b border-[var(--color-ts-border)] bg-[var(--color-ts-surface)]/80 backdrop-blur-sm shrink-0">
          <button
            className="lg:hidden text-[var(--color-ts-muted)] hover:text-[var(--color-foreground)] transition-colors"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 ml-auto">
            <span className="text-xs text-[var(--color-ts-muted)] bg-[var(--color-ts-surface-2)] px-2 py-1 rounded-full border border-[var(--color-ts-border)]">
              Demo Mode
            </span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
