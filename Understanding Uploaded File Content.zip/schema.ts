import {
  int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal, json, tinyint,
} from "drizzle-orm/mysql-core";

/* ─── Users ──────────────────────────────────────────────────────────────── */
export const users = mysqlTable("users", {
  id:           int("id").autoincrement().primaryKey(),
  openId:       varchar("openId", { length: 64 }).notNull().unique(),
  name:         text("name"),
  email:        varchar("email", { length: 320 }),
  loginMethod:  varchar("loginMethod", { length: 64 }),
  role:         mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt:    timestamp("createdAt").defaultNow().notNull(),
  updatedAt:    timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/* ─── Organizations ──────────────────────────────────────────────────────── */
export const organizations = mysqlTable("organizations", {
  id:          int("id").autoincrement().primaryKey(),
  name:        varchar("name", { length: 255 }).notNull(),
  slug:        varchar("slug", { length: 128 }).notNull().unique(),
  plan:        mysqlEnum("plan", ["pilot", "growth", "enterprise"]).default("pilot").notNull(),
  ownerId:     int("ownerId").notNull(),
  createdAt:   timestamp("createdAt").defaultNow().notNull(),
  updatedAt:   timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/* ─── Stores ─────────────────────────────────────────────────────────────── */
export const stores = mysqlTable("stores", {
  id:             int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  platform:       mysqlEnum("platform", ["shopify", "woocommerce", "custom"]).notNull(),
  name:           varchar("name", { length: 255 }).notNull(),
  url:            varchar("url", { length: 512 }),
  accessToken:    text("accessToken"),
  isConnected:    boolean("isConnected").default(false).notNull(),
  lastSyncedAt:   timestamp("lastSyncedAt"),
  createdAt:      timestamp("createdAt").defaultNow().notNull(),
  updatedAt:      timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/* ─── Products ───────────────────────────────────────────────────────────── */
export const products = mysqlTable("products", {
  id:             int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  storeId:        int("storeId").notNull(),
  externalId:     varchar("externalId", { length: 128 }),
  name:           varchar("name", { length: 255 }).notNull(),
  description:    text("description"),
  vendor:         varchar("vendor", { length: 128 }),
  category:       varchar("category", { length: 128 }),
  price:          decimal("price", { precision: 10, scale: 2 }),
  imageUrl:       text("imageUrl"),
  tryOnEnabled:   boolean("tryOnEnabled").default(false).notNull(),
  tryOnAssetKey:  text("tryOnAssetKey"),
  createdAt:      timestamp("createdAt").defaultNow().notNull(),
  updatedAt:      timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/* ─── Product Variants ───────────────────────────────────────────────────── */
export const productVariants = mysqlTable("product_variants", {
  id:        int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  name:      varchar("name", { length: 128 }).notNull(),
  sku:       varchar("sku", { length: 128 }),
  color:     varchar("color", { length: 64 }),
  size:      varchar("size", { length: 32 }),
  price:     decimal("price", { precision: 10, scale: 2 }),
  inStock:   boolean("inStock").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

/* ─── Widget Settings ────────────────────────────────────────────────────── */
export const widgetSettings = mysqlTable("widget_settings", {
  id:             int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull().unique(),
  buttonText:     varchar("buttonText", { length: 64 }).default("Try It On").notNull(),
  buttonColor:    varchar("buttonColor", { length: 16 }).default("#3B82F6").notNull(),
  textColor:      varchar("textColor", { length: 16 }).default("#FFFFFF").notNull(),
  borderRadius:   int("borderRadius").default(8).notNull(),
  fontFamily:     varchar("fontFamily", { length: 64 }).default("Inter").notNull(),
  placement:      varchar("placement", { length: 64 }).default("above-add-to-cart").notNull(),
  isPublished:    boolean("isPublished").default(false).notNull(),
  publishedAt:    timestamp("publishedAt"),
  createdAt:      timestamp("createdAt").defaultNow().notNull(),
  updatedAt:      timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/* ─── Try-On Sessions ────────────────────────────────────────────────────── */
export const tryOnSessions = mysqlTable("try_on_sessions", {
  id:             int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  productId:      int("productId"),
  variantId:      int("variantId"),
  sessionToken:   varchar("sessionToken", { length: 128 }).notNull().unique(),
  status:         mysqlEnum("status", ["initiated", "generated", "saved", "abandoned"]).default("initiated").notNull(),
  photoConsent:   boolean("photoConsent").default(false).notNull(),
  photoDeletedAt: timestamp("photoDeletedAt"),
  createdAt:      timestamp("createdAt").defaultNow().notNull(),
  completedAt:    timestamp("completedAt"),
});

/* ─── Generated Looks ────────────────────────────────────────────────────── */
export const generatedLooks = mysqlTable("generated_looks", {
  id:          int("id").autoincrement().primaryKey(),
  sessionId:   int("sessionId").notNull(),
  productId:   int("productId").notNull(),
  variantId:   int("variantId"),
  imageKey:    text("imageKey"),
  imageUrl:    text("imageUrl"),
  isDeleted:   boolean("isDeleted").default(false).notNull(),
  deletedAt:   timestamp("deletedAt"),
  createdAt:   timestamp("createdAt").defaultNow().notNull(),
});

/* ─── Analytics Events ───────────────────────────────────────────────────── */
export const analyticsEvents = mysqlTable("analytics_events", {
  id:             int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  productId:      int("productId"),
  sessionId:      int("sessionId"),
  eventType:      mysqlEnum("eventType", ["widget_view", "try_on_open", "generate", "add_to_cart", "purchase"]).notNull(),
  metadata:       json("metadata"),
  occurredAt:     timestamp("occurredAt").defaultNow().notNull(),
});

/* ─── Subscriptions ──────────────────────────────────────────────────────── */
export const subscriptions = mysqlTable("subscriptions", {
  id:                  int("id").autoincrement().primaryKey(),
  organizationId:      int("organizationId").notNull().unique(),
  plan:                mysqlEnum("plan", ["pilot", "growth", "enterprise"]).default("pilot").notNull(),
  status:              mysqlEnum("status", ["active", "past_due", "cancelled"]).default("active").notNull(),
  sessionsIncluded:    int("sessionsIncluded").default(500).notNull(),
  sessionsUsed:        int("sessionsUsed").default(0).notNull(),
  currentPeriodStart:  timestamp("currentPeriodStart").defaultNow().notNull(),
  currentPeriodEnd:    timestamp("currentPeriodEnd").notNull(),
  createdAt:           timestamp("createdAt").defaultNow().notNull(),
  updatedAt:           timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/* ─── Audit Logs ─────────────────────────────────────────────────────────── */
export const auditLogs = mysqlTable("audit_logs", {
  id:             int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull(),
  userId:         int("userId"),
  action:         varchar("action", { length: 128 }).notNull(),
  resource:       varchar("resource", { length: 128 }),
  resourceId:     int("resourceId"),
  metadata:       json("metadata"),
  createdAt:      timestamp("createdAt").defaultNow().notNull(),
});

/* ─── Types ──────────────────────────────────────────────────────────────── */
export type User             = typeof users.$inferSelect;
export type InsertUser       = typeof users.$inferInsert;
export type Organization     = typeof organizations.$inferSelect;
export type Store            = typeof stores.$inferSelect;
export type Product          = typeof products.$inferSelect;
export type ProductVariant   = typeof productVariants.$inferSelect;
export type WidgetSettings   = typeof widgetSettings.$inferSelect;
export type TryOnSession     = typeof tryOnSessions.$inferSelect;
export type GeneratedLook    = typeof generatedLooks.$inferSelect;
export type AnalyticsEvent   = typeof analyticsEvents.$inferSelect;
export type Subscription     = typeof subscriptions.$inferSelect;
export type AuditLog         = typeof auditLogs.$inferSelect;

/* ─── Provider Management ────────────────────────────────────────────────── */
export const tryOnProviders = mysqlTable("try_on_providers", {
  id:                    int("id").autoincrement().primaryKey(),
  name:                  varchar("name", { length: 128 }).notNull().unique(),
  description:           text("description"),
  status:                mysqlEnum("status", ["active", "inactive", "maintenance", "deprecated"]).default("active").notNull(),
  supportedCategories:   json("supportedCategories"),
  estimatedCost:         decimal("estimatedCost", { precision: 10, scale: 4 }),
  expectedGenerationTime: int("expectedGenerationTime"),
  qualityRating:         decimal("qualityRating", { precision: 3, scale: 2 }),
  createdAt:             timestamp("createdAt").defaultNow().notNull(),
  updatedAt:             timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const providerCapabilities = mysqlTable("provider_capabilities", {
  id:                  int("id").autoincrement().primaryKey(),
  providerId:          int("providerId").notNull(),
  category:            varchar("category", { length: 128 }).notNull(),
  supportedVariants:   json("supportedVariants"),
  maxImageSize:        int("maxImageSize"),
  supportedFormats:    json("supportedFormats"),
  createdAt:           timestamp("createdAt").defaultNow().notNull(),
});

export const providerHealth = mysqlTable("provider_health", {
  id:                    int("id").autoincrement().primaryKey(),
  providerId:            int("providerId").notNull(),
  successRate:           decimal("successRate", { precision: 5, scale: 2 }),
  averageGenerationTime: int("averageGenerationTime"),
  lastHealthCheck:       timestamp("lastHealthCheck"),
  status:                mysqlEnum("status", ["healthy", "degraded", "down"]).default("healthy").notNull(),
  updatedAt:             timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const providerRequests = mysqlTable("provider_requests", {
  id:              int("id").autoincrement().primaryKey(),
  organizationId:  int("organizationId").notNull(),
  providerId:      int("providerId").notNull(),
  tryOnRequestId:  int("tryOnRequestId"),
  status:          mysqlEnum("status", ["pending", "processing", "completed", "failed", "retry"]).default("pending").notNull(),
  requestPayload:  json("requestPayload"),
  responsePayload: json("responsePayload"),
  errorMessage:    text("errorMessage"),
  retryCount:      int("retryCount").default(0),
  createdAt:       timestamp("createdAt").defaultNow().notNull(),
  completedAt:     timestamp("completedAt"),
});

/* ─── Quality Evaluation ─────────────────────────────────────────────────── */
export const qualityEvaluations = mysqlTable("quality_evaluations", {
  id:                       int("id").autoincrement().primaryKey(),
  tryOnResultId:            int("tryOnResultId").notNull(),
  facePreservation:         decimal("facePreservation", { precision: 3, scale: 2 }),
  bodyPreservation:         decimal("bodyPreservation", { precision: 3, scale: 2 }),
  garmentColorAccuracy:     decimal("garmentColorAccuracy", { precision: 3, scale: 2 }),
  patternPreservation:      decimal("patternPreservation", { precision: 3, scale: 2 }),
  logoPreservation:         decimal("logoPreservation", { precision: 3, scale: 2 }),
  silhouetteAccuracy:       decimal("silhouetteAccuracy", { precision: 3, scale: 2 }),
  limbArtifacts:            decimal("limbArtifacts", { precision: 3, scale: 2 }),
  occlusionQuality:         decimal("occlusionQuality", { precision: 3, scale: 2 }),
  backgroundPreservation:   decimal("backgroundPreservation", { precision: 3, scale: 2 }),
  overallPhotorealism:      decimal("overallPhotorealism", { precision: 3, scale: 2 }),
  merchantApproval:         boolean("merchantApproval"),
  shopperApproval:          boolean("shopperApproval"),
  overallScore:             decimal("overallScore", { precision: 3, scale: 2 }),
  evaluatedBy:              int("evaluatedBy"),
  evaluatedAt:              timestamp("evaluatedAt").defaultNow().notNull(),
});

/* ─── Garment Data Standard ──────────────────────────────────────────────── */
export const garmentRecords = mysqlTable("garment_records", {
  id:                  int("id").autoincrement().primaryKey(),
  organizationId:      int("organizationId").notNull(),
  productId:           int("productId").notNull(),
  merchantProductId:   varchar("merchantProductId", { length: 128 }),
  title:               varchar("title", { length: 255 }).notNull(),
  brand:               varchar("brand", { length: 128 }),
  category:            varchar("category", { length: 128 }).notNull(),
  subcategory:         varchar("subcategory", { length: 128 }),
  garmentType:         varchar("garmentType", { length: 128 }),
  silhouette:          varchar("silhouette", { length: 128 }),
  fabricComposition:   text("fabricComposition"),
  stretchLevel:        mysqlEnum("stretchLevel", ["none", "low", "medium", "high"]).default("medium"),
  opacity:             mysqlEnum("opacity", ["opaque", "translucent", "sheer"]).default("opaque"),
  weight:              varchar("weight", { length: 64 }),
  fitDescription:      text("fitDescription"),
  closureType:         varchar("closureType", { length: 128 }),
  careInstructions:    text("careInstructions"),
  frontImageKey:       text("frontImageKey"),
  backImageKey:        text("backImageKey"),
  flatLayImageKey:     text("flatLayImageKey"),
  modelImageKey:       text("modelImageKey"),
  detailImageKeys:     json("detailImageKeys"),
  modelMeasurements:   json("modelMeasurements"),
  createdAt:           timestamp("createdAt").defaultNow().notNull(),
  updatedAt:           timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const sizeCharts = mysqlTable("size_charts", {
  id:              int("id").autoincrement().primaryKey(),
  garmentRecordId: int("garmentRecordId").notNull(),
  size:            varchar("size", { length: 32 }).notNull(),
  bust:            decimal("bust", { precision: 6, scale: 2 }),
  waist:           decimal("waist", { precision: 6, scale: 2 }),
  hips:            decimal("hips", { precision: 6, scale: 2 }),
  length:          decimal("length", { precision: 6, scale: 2 }),
  sleeve:          decimal("sleeve", { precision: 6, scale: 2 }),
  shoulder:        decimal("shoulder", { precision: 6, scale: 2 }),
  notes:           text("notes"),
});

/* ─── Shopper Profiles & Measurements ────────────────────────────────────── */
export const shopperProfiles = mysqlTable("shopper_profiles", {
  id:               int("id").autoincrement().primaryKey(),
  organizationId:   int("organizationId").notNull(),
  sessionToken:     varchar("sessionToken", { length: 128 }).unique(),
  height:           varchar("height", { length: 32 }),
  weightRange:      varchar("weightRange", { length: 32 }),
  usualTopSize:     varchar("usualTopSize", { length: 32 }),
  usualBottomSize:  varchar("usualBottomSize", { length: 32 }),
  fitPreference:    varchar("fitPreference", { length: 128 }),
  preferredBrands:  json("preferredBrands"),
  createdAt:        timestamp("createdAt").defaultNow().notNull(),
  updatedAt:        timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const shopperMeasurements = mysqlTable("shopper_measurements", {
  id:               int("id").autoincrement().primaryKey(),
  shopperProfileId: int("shopperProfileId").notNull(),
  chest:            decimal("chest", { precision: 6, scale: 2 }),
  waist:            decimal("waist", { precision: 6, scale: 2 }),
  hips:             decimal("hips", { precision: 6, scale: 2 }),
  inseam:           decimal("inseam", { precision: 6, scale: 2 }),
  recordedAt:       timestamp("recordedAt").defaultNow().notNull(),
});

/* ─── Try-On Flow ────────────────────────────────────────────────────────── */
export const tryOnRequests = mysqlTable("try_on_requests", {
  id:                    int("id").autoincrement().primaryKey(),
  organizationId:        int("organizationId").notNull(),
  productId:             int("productId"),
  variantId:             int("variantId"),
  shopperProfileId:      int("shopperProfileId"),
  sessionToken:          varchar("sessionToken", { length: 128 }).notNull().unique(),
  status:                mysqlEnum("status", ["initiated", "photo_uploaded", "generation_started", "generation_completed", "result_accepted", "result_regenerated", "result_saved", "result_shared", "abandoned"]).default("initiated").notNull(),
  photoConsent:          boolean("photoConsent").default(false).notNull(),
  photoUploadedAt:       timestamp("photoUploadedAt"),
  generationStartedAt:   timestamp("generationStartedAt"),
  generationCompletedAt: timestamp("generationCompletedAt"),
  resultAcceptedAt:      timestamp("resultAcceptedAt"),
  photoDeletedAt:        timestamp("photoDeletedAt"),
  createdAt:             timestamp("createdAt").defaultNow().notNull(),
});

export const tryOnResults = mysqlTable("try_on_results", {
  id:                        int("id").autoincrement().primaryKey(),
  tryOnRequestId:            int("tryOnRequestId").notNull(),
  productId:                 int("productId").notNull(),
  variantId:                 int("variantId"),
  selectedColor:             varchar("selectedColor", { length: 128 }),
  selectedSize:              varchar("selectedSize", { length: 32 }),
  generatedImageKey:         text("generatedImageKey"),
  generatedImageUrl:         text("generatedImageUrl"),
  originalPhotoKey:          text("originalPhotoKey"),
  qualityScore:              decimal("qualityScore", { precision: 3, scale: 2 }),
  productFidelityScore:      decimal("productFidelityScore", { precision: 3, scale: 2 }),
  identityPreservationScore: decimal("identityPreservationScore", { precision: 3, scale: 2 }),
  warnings:                  json("warnings"),
  isDeleted:                 boolean("isDeleted").default(false).notNull(),
  deletedAt:                 timestamp("deletedAt"),
  createdAt:                 timestamp("createdAt").defaultNow().notNull(),
});

/* ─── Fit Recommendations ────────────────────────────────────────────────── */
export const fitRecommendations = mysqlTable("fit_recommendations", {
  id:                  int("id").autoincrement().primaryKey(),
  tryOnRequestId:      int("tryOnRequestId").notNull(),
  garmentRecordId:     int("garmentRecordId").notNull(),
  recommendedSize:     varchar("recommendedSize", { length: 32 }),
  alternativeSize:     varchar("alternativeSize", { length: 32 }),
  confidencePercentage: int("confidencePercentage"),
  fitNotes:            text("fitNotes"),
  explanation:         text("explanation"),
  feedbackRequested:   boolean("feedbackRequested").default(true),
  shopperFeedback:     mysqlEnum("shopperFeedback", ["fits_well", "too_small", "too_large", "other"]),
  feedbackProvidedAt:  timestamp("feedbackProvidedAt"),
  createdAt:           timestamp("createdAt").defaultNow().notNull(),
});

/* ─── Commerce Tracking ──────────────────────────────────────────────────── */
export const storefrontEvents = mysqlTable("storefront_events", {
  id:              int("id").autoincrement().primaryKey(),
  organizationId:  int("organizationId").notNull(),
  productId:       int("productId"),
  tryOnRequestId:  int("tryOnRequestId"),
  tryOnResultId:   int("tryOnResultId"),
  eventType:       mysqlEnum("eventType", ["widget_view", "try_on_open", "photo_upload", "generation_started", "generation_completed", "result_accepted", "result_regenerated", "result_saved", "result_shared", "size_selected", "variant_selected", "add_to_cart", "checkout_started", "purchase_completed", "return_initiated", "return_reason", "size_exchange"]).notNull(),
  metadata:        json("metadata"),
  occurredAt:      timestamp("occurredAt").defaultNow().notNull(),
});

export const purchases = mysqlTable("purchases", {
  id:              int("id").autoincrement().primaryKey(),
  organizationId:  int("organizationId").notNull(),
  tryOnRequestId:  int("tryOnRequestId"),
  productId:       int("productId"),
  variantId:       int("variantId"),
  selectedSize:    varchar("selectedSize", { length: 32 }),
  selectedColor:   varchar("selectedColor", { length: 128 }),
  orderValue:      decimal("orderValue", { precision: 10, scale: 2 }),
  usedTryOn:       boolean("usedTryOn").default(false).notNull(),
  purchasedAt:     timestamp("purchasedAt").defaultNow().notNull(),
});

export const returns = mysqlTable("returns", {
  id:              int("id").autoincrement().primaryKey(),
  organizationId:  int("organizationId").notNull(),
  purchaseId:      int("purchaseId"),
  tryOnRequestId:  int("tryOnRequestId"),
  productId:       int("productId"),
  reason:          varchar("reason", { length: 256 }),
  reasonCategory:  mysqlEnum("reasonCategory", ["wrong_size", "wrong_color", "quality", "fit", "changed_mind", "other"]),
  sizeExchange:    varchar("sizeExchange", { length: 32 }),
  returnedAt:      timestamp("returnedAt").defaultNow().notNull(),
});

/* ─── Content Generation & Assets ────────────────────────────────────────── */
export const generatedAssets = mysqlTable("generated_assets", {
  id:              int("id").autoincrement().primaryKey(),
  organizationId:  int("organizationId").notNull(),
  productId:       int("productId").notNull(),
  assetType:       mysqlEnum("assetType", ["on_model", "lifestyle", "multiple_body", "flat_lay", "detail"]).notNull(),
  modelType:       varchar("modelType", { length: 128 }),
  imageKey:        text("imageKey"),
  imageUrl:        text("imageUrl"),
  campaign:        varchar("campaign", { length: 128 }),
  approvalStatus:  mysqlEnum("approvalStatus", ["pending", "approved", "rejected"]).default("pending"),
  approvedBy:      int("approvedBy"),
  approvedAt:      timestamp("approvedAt"),
  createdAt:       timestamp("createdAt").defaultNow().notNull(),
});

/* ─── Pilot Program ──────────────────────────────────────────────────────── */
export const pilotAccounts = mysqlTable("pilot_accounts", {
  id:                       int("id").autoincrement().primaryKey(),
  organizationId:           int("organizationId").notNull().unique(),
  companyName:              varchar("companyName", { length: 255 }).notNull(),
  website:                  varchar("website", { length: 512 }),
  ecommercePlatform:        varchar("ecommercePlatform", { length: 128 }),
  monthlyWebsiteTraffic:    int("monthlyWebsiteTraffic"),
  estimatedMonthlyRevenue:  varchar("estimatedMonthlyRevenue", { length: 64 }),
  productCategory:          varchar("productCategory", { length: 128 }),
  numberOfProducts:         int("numberOfProducts"),
  approximateReturnRate:    decimal("approximateReturnRate", { precision: 5, scale: 2 }),
  biggestProblem:           text("biggestProblem"),
  contactEmail:             varchar("contactEmail", { length: 320 }),
  contactPhone:             varchar("contactPhone", { length: 32 }),
  interestInPaidPilot:      boolean("interestInPaidPilot"),
  applicationStatus:        mysqlEnum("applicationStatus", ["pending", "approved", "rejected", "active", "completed"]).default("pending").notNull(),
  pilotStartDate:           timestamp("pilotStartDate"),
  pilotEndDate:             timestamp("pilotEndDate"),
  appliedAt:                timestamp("appliedAt").defaultNow().notNull(),
  approvedAt:               timestamp("approvedAt"),
});

export const pilotFeedback = mysqlTable("pilot_feedback", {
  id:              int("id").autoincrement().primaryKey(),
  pilotAccountId:  int("pilotAccountId").notNull(),
  feedbackType:    mysqlEnum("feedbackType", ["merchant", "shopper", "weekly_summary"]).notNull(),
  rating:          int("rating"),
  comment:         text("comment"),
  caseStudyData:   json("caseStudyData"),
  submittedAt:     timestamp("submittedAt").defaultNow().notNull(),
});

/* ─── Usage & Billing ────────────────────────────────────────────────────── */
export const usageRecords = mysqlTable("usage_records", {
  id:                      int("id").autoincrement().primaryKey(),
  organizationId:          int("organizationId").notNull(),
  billingPeriodStart:      timestamp("billingPeriodStart").notNull(),
  billingPeriodEnd:        timestamp("billingPeriodEnd").notNull(),
  generationsRequested:    int("generationsRequested").default(0),
  generationsCompleted:    int("generationsCompleted").default(0),
  estimatedGenerationCost: decimal("estimatedGenerationCost", { precision: 10, scale: 2 }),
  eventsTracked:           int("eventsTracked").default(0),
  storageUsedMb:           int("storageUsedMb").default(0),
  createdAt:               timestamp("createdAt").defaultNow().notNull(),
});

/* ─── Types ──────────────────────────────────────────────────────────────── */
export type TryOnProvider       = typeof tryOnProviders.$inferSelect;
export type ProviderCapability  = typeof providerCapabilities.$inferSelect;
export type ProviderHealth      = typeof providerHealth.$inferSelect;
export type ProviderRequest     = typeof providerRequests.$inferSelect;
export type QualityEvaluation   = typeof qualityEvaluations.$inferSelect;
export type GarmentRecord       = typeof garmentRecords.$inferSelect;
export type SizeChart           = typeof sizeCharts.$inferSelect;
export type ShopperProfile      = typeof shopperProfiles.$inferSelect;
export type ShopperMeasurement  = typeof shopperMeasurements.$inferSelect;
export type TryOnRequest        = typeof tryOnRequests.$inferSelect;
export type TryOnResult         = typeof tryOnResults.$inferSelect;
export type FitRecommendation   = typeof fitRecommendations.$inferSelect;
export type StorefrontEvent     = typeof storefrontEvents.$inferSelect;
export type Purchase            = typeof purchases.$inferSelect;
export type Return              = typeof returns.$inferSelect;
export type GeneratedAsset      = typeof generatedAssets.$inferSelect;
export type PilotAccount        = typeof pilotAccounts.$inferSelect;
export type PilotFeedback       = typeof pilotFeedback.$inferSelect;
export type UsageRecord         = typeof usageRecords.$inferSelect;
