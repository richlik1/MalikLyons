import { useState } from "react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar,
} from "recharts";
import {
  TrendingUp, ShoppingBag, DollarSign, Package, ArrowUpRight,
  ArrowRight, CheckCircle2, Circle, Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ── Demo data ─────────────────────────────────────────────────────────── */
const SESSIONS_DATA = [
  { day: "Mon", sessions: 142, conversions: 28 },
  { day: "Tue", sessions: 198, conversions: 41 },
  { day: "Wed", sessions: 176, conversions: 35 },
  { day: "Thu", sessions: 241, conversions: 58 },
  { day: "Fri", sessions: 312, conversions: 74 },
  { day: "Sat", sessions: 389, conversions: 92 },
  { day: "Sun", sessions: 267, conversions: 63 },
];

const TOP_PRODUCTS = [
  { name: "Silk Wrap Dress",    sessions: 312, conversion: "28.4%", revenue: "$4,820" },
  { name: "Linen Blazer",       sessions: 241, conversion: "24.1%", revenue: "$3,610" },
  { name: "Wide-Leg Trousers",  sessions: 198, conversion: "21.7%", revenue: "$2,940" },
  { name: "Floral Midi Skirt",  sessions: 167, conversion: "19.8%", revenue: "$2,180" },
  { name: "Cashmere Sweater",   sessions: 143, conversion: "17.5%", revenue: "$1,920" },
];

const ACTIVITY = [
  { time: "2 min ago",  text: "New try-on session — Silk Wrap Dress (Ocean Blue)",    type: "session" },
  { time: "8 min ago",  text: "Add to cart — Linen Blazer, Size M",                   type: "cart" },
  { time: "14 min ago", text: "New try-on session — Wide-Leg Trousers (Ivory)",       type: "session" },
  { time: "22 min ago", text: "Purchase completed — Floral Midi Skirt × 1",           type: "purchase" },
  { time: "31 min ago", text: "New try-on session — Cashmere Sweater (Caramel)",      type: "session" },
];

const CHECKLIST = [
  { label: "Connect your store",         done: true },
  { label: "Import product catalog",     done: true },
  { label: "Enable try-on on products",  done: true },
  { label: "Customize widget",           done: false },
  { label: "Publish to storefront",      done: false },
];

/* ── KPI Card ──────────────────────────────────────────────────────────── */
function KpiCard({
  label, value, delta, icon: Icon, accent,
}: {
  label: string; value: string; delta: string; icon: React.ElementType; accent: string;
}) {
  return (
    <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-6 shadow-card hover:border-[var(--color-ts-border-light)] transition-colors">
      <div className="flex items-start justify-between mb-4">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: `${accent}18`, border: `1px solid ${accent}30` }}
        >
          <Icon className="w-5 h-5" style={{ color: accent }} />
        </div>
        <Badge className="text-xs bg-green-500/10 text-green-400 border-green-500/20">
          <ArrowUpRight className="w-3 h-3 mr-0.5" />
          {delta}
        </Badge>
      </div>
      <div className="font-serif text-3xl font-light text-white mb-1">{value}</div>
      <div className="text-xs text-[var(--color-ts-muted)] capitalize">{label}</div>
    </div>
  );
}

/* ── Custom Tooltip ────────────────────────────────────────────────────── */
function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[var(--color-ts-surface-2)] border border-[var(--color-ts-border)] rounded-xl p-3 shadow-elevated text-xs">
      <div className="text-[var(--color-ts-muted)] mb-2">{label}</div>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: p.color }} />
          <span className="text-white capitalize">{p.name}:</span>
          <span className="text-[var(--color-ts-muted)]">{p.value}</span>
        </div>
      ))}
    </div>
  );
}

/* ── Page ──────────────────────────────────────────────────────────────── */
export default function Overview() {
  const [range] = useState("7d");

  return (
    <div className="p-6 lg:p-8 space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-serif text-3xl font-light text-white">Overview</h1>
          <p className="text-sm text-[var(--color-ts-muted)] mt-1">Welcome back. Here's what's happening with your store.</p>
        </div>
        <Badge className="bg-[var(--color-ts-violet)]/10 text-[var(--color-ts-violet-light)] border-[var(--color-ts-violet)]/20 text-xs">
          Demo Data
        </Badge>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="try-on sessions"  value="1,725" delta="+18.4%" icon={Zap}         accent="#3B82F6" />
        <KpiCard label="conversion rate"  value="23.8%" delta="+3.2%"  icon={TrendingUp}  accent="#8B5CF6" />
        <KpiCard label="revenue lift"     value="$14.2k" delta="+24.1%" icon={DollarSign} accent="#10B981" />
        <KpiCard label="active products"  value="8"     delta="+2"     icon={Package}     accent="#F59E0B" />
      </div>

      {/* Charts row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Sessions chart */}
        <div className="lg:col-span-2 bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-6 shadow-card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-serif text-lg font-medium text-white">Try-On Activity</h2>
            <span className="text-xs text-[var(--color-ts-muted)]">Last 7 days</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={SESSIONS_DATA} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="gradSessions" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#3B82F6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gradConversions" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#8B5CF6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.008 260)" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: "oklch(0.55 0.01 260)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "oklch(0.55 0.01 260)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTooltip />} />
              <Area type="monotone" dataKey="sessions"    stroke="#3B82F6" strokeWidth={2} fill="url(#gradSessions)"    dot={false} />
              <Area type="monotone" dataKey="conversions" stroke="#8B5CF6" strokeWidth={2} fill="url(#gradConversions)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-4">
            {[["#3B82F6", "Sessions"], ["#8B5CF6", "Conversions"]].map(([c, l]) => (
              <div key={l} className="flex items-center gap-1.5 text-xs text-[var(--color-ts-muted)]">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: c }} />
                {l}
              </div>
            ))}
          </div>
        </div>

        {/* Funnel */}
        <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-6 shadow-card">
          <h2 className="font-serif text-lg font-medium text-white mb-6">Conversion Funnel</h2>
          <div className="space-y-3">
            {[
              { label: "Viewed widget",  value: 3240, pct: 100,  color: "#3B82F6" },
              { label: "Opened try-on",  value: 1725, pct: 53.2, color: "#8B5CF6" },
              { label: "Generated look", value: 1240, pct: 38.3, color: "#EC4899" },
              { label: "Added to cart",  value: 411,  pct: 12.7, color: "#10B981" },
              { label: "Purchased",      value: 198,  pct: 6.1,  color: "#F59E0B" },
            ].map((step) => (
              <div key={step.label}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-[var(--color-ts-muted)]">{step.label}</span>
                  <span className="text-white">{step.value.toLocaleString()}</span>
                </div>
                <div className="h-2 bg-[var(--color-ts-surface-2)] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${step.pct}%`, backgroundColor: step.color }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Top products */}
        <div className="lg:col-span-2 bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-6 shadow-card">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-serif text-lg font-medium text-white">Top Products</h2>
            <Link href="/dashboard/products">
              <Button variant="ghost" size="sm" className="text-xs text-[var(--color-ts-muted)] hover:text-white">
                View all <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            </Link>
          </div>
          <div className="space-y-1">
            <div className="grid grid-cols-4 text-xs text-[var(--color-ts-muted)] pb-2 border-b border-[var(--color-ts-border)]">
              <span className="col-span-2">Product</span>
              <span className="text-right">Sessions</span>
              <span className="text-right">Revenue</span>
            </div>
            {TOP_PRODUCTS.map((p, i) => (
              <div key={p.name} className="grid grid-cols-4 py-3 text-sm border-b border-[var(--color-ts-border)]/50 last:border-0 hover:bg-[var(--color-ts-surface-2)] rounded-lg px-2 -mx-2 transition-colors">
                <div className="col-span-2 flex items-center gap-2">
                  <span className="text-xs text-[var(--color-ts-muted-2)] w-4 shrink-0">{i + 1}</span>
                  <span className="text-white truncate">{p.name}</span>
                </div>
                <span className="text-right text-[var(--color-ts-muted)]">{p.sessions}</span>
                <span className="text-right text-[var(--color-ts-blue-light)]">{p.revenue}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-5">
          {/* Recent activity */}
          <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-5 shadow-card">
            <h2 className="font-serif text-base font-medium text-white mb-4">Recent Activity</h2>
            <div className="space-y-3">
              {ACTIVITY.map((a, i) => (
                <div key={i} className="flex gap-2.5">
                  <div className={cn(
                    "w-1.5 h-1.5 rounded-full mt-1.5 shrink-0",
                    a.type === "purchase" ? "bg-green-400" :
                    a.type === "cart"     ? "bg-[var(--color-ts-violet-light)]" :
                                           "bg-[var(--color-ts-blue-light)]"
                  )} />
                  <div>
                    <p className="text-xs text-[var(--color-foreground)] leading-relaxed">{a.text}</p>
                    <p className="text-[10px] text-[var(--color-ts-muted)] mt-0.5">{a.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Setup checklist */}
          <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-5 shadow-card">
            <h2 className="font-serif text-base font-medium text-white mb-4">Setup Checklist</h2>
            <div className="space-y-2.5">
              {CHECKLIST.map((item) => (
                <div key={item.label} className="flex items-center gap-2.5">
                  {item.done
                    ? <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                    : <Circle className="w-4 h-4 text-[var(--color-ts-muted-2)] shrink-0" />
                  }
                  <span className={cn("text-xs", item.done ? "text-[var(--color-ts-muted)] line-through" : "text-white")}>
                    {item.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
