import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  CheckCircle2, XCircle, RefreshCw, ExternalLink, Copy, Check,
  Plug, Zap, Code2, AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

type IntegrationStatus = "connected" | "disconnected" | "error";

interface Integration {
  id: string;
  name: string;
  description: string;
  status: IntegrationStatus;
  lastSync: string | null;
  webhookStatus: "active" | "inactive" | null;
  storeUrl: string | null;
  icon: string;
  color: string;
  setupSteps: string[];
}

const INITIAL_INTEGRATIONS: Integration[] = [
  {
    id: "shopify",
    name: "Shopify",
    description: "Connect your Shopify store to automatically sync products, variants, and pricing. The try-on widget integrates directly into your product pages.",
    status: "connected",
    lastSync: "2 minutes ago",
    webhookStatus: "active",
    storeUrl: "lumiere-boutique.myshopify.com",
    icon: "🛍️",
    color: "#96BF48",
    setupSteps: [
      "Install the Trendset app from the Shopify App Store",
      "Authorize the OAuth connection",
      "Select products to enable try-on",
      "Publish the widget to your theme",
    ],
  },
  {
    id: "woocommerce",
    name: "WooCommerce",
    description: "Integrate with your WooCommerce store via our WordPress plugin. Supports all WooCommerce product types and variable products.",
    status: "disconnected",
    lastSync: null,
    webhookStatus: null,
    storeUrl: null,
    icon: "🔌",
    color: "#7F54B3",
    setupSteps: [
      "Download the Trendset WooCommerce plugin",
      "Install and activate in WordPress admin",
      "Enter your Trendset API key in plugin settings",
      "Configure product sync and widget placement",
    ],
  },
  {
    id: "custom",
    name: "Custom API",
    description: "Use the Trendset REST API to integrate with any custom storefront, headless commerce setup, or proprietary platform.",
    status: "disconnected",
    lastSync: null,
    webhookStatus: null,
    storeUrl: null,
    icon: "⚙️",
    color: "#3B82F6",
    setupSteps: [
      "Generate an API key from your dashboard",
      "Install the Trendset JS SDK via npm or CDN",
      "Initialize the SDK with your API key",
      "Call trendset.render() on product pages",
    ],
  },
];

function StatusBadge({ status }: { status: IntegrationStatus }) {
  return (
    <Badge
      className={cn(
        "text-xs border",
        status === "connected"    ? "bg-green-500/10 text-green-400 border-green-500/20" :
        status === "error"        ? "bg-red-500/10 text-red-400 border-red-500/20" :
                                    "bg-[var(--color-ts-surface-2)] text-[var(--color-ts-muted)] border-[var(--color-ts-border)]"
      )}
    >
      {status === "connected"    ? <CheckCircle2 className="w-3 h-3 mr-1" /> :
       status === "error"        ? <XCircle className="w-3 h-3 mr-1" /> :
                                   <XCircle className="w-3 h-3 mr-1" />}
      {status === "connected" ? "Connected" : status === "error" ? "Error" : "Not connected"}
    </Badge>
  );
}

export default function Integrations() {
  const [integrations, setIntegrations] = useState(INITIAL_INTEGRATIONS);
  const [setupOpen, setSetupOpen] = useState<Integration | null>(null);
  const [syncing, setSyncing] = useState<string | null>(null);
  const [apiKeyCopied, setApiKeyCopied] = useState(false);
  const DEMO_API_KEY = "ts_live_pk_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6";

  const handleSync = (id: string) => {
    setSyncing(id);
    setTimeout(() => {
      setSyncing(null);
      setIntegrations((prev) => prev.map((i) =>
        i.id === id ? { ...i, lastSync: "Just now" } : i
      ));
      toast.success("Product sync complete — 12 products updated");
    }, 2000);
  };

  const handleConnect = (id: string) => {
    setIntegrations((prev) => prev.map((i) =>
      i.id === id ? { ...i, status: "connected" as IntegrationStatus, lastSync: "Just now", webhookStatus: "active" } : i
    ));
    setSetupOpen(null);
    toast.success("Integration connected successfully (demo mode)");
  };

  const handleDisconnect = (id: string) => {
    setIntegrations((prev) => prev.map((i) =>
      i.id === id ? { ...i, status: "disconnected" as IntegrationStatus, lastSync: null, webhookStatus: null, storeUrl: null } : i
    ));
    toast.success("Integration disconnected");
  };

  const copyApiKey = () => {
    navigator.clipboard.writeText(DEMO_API_KEY);
    setApiKeyCopied(true);
    toast.success("API key copied");
    setTimeout(() => setApiKeyCopied(false), 2000);
  };

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div>
        <h1 className="font-serif text-3xl font-light text-white">Integrations</h1>
        <p className="text-sm text-[var(--color-ts-muted)] mt-1">Connect your storefront to activate virtual try-on</p>
      </div>

      {/* Integration cards */}
      <div className="space-y-4">
        {integrations.map((integration) => (
          <div
            key={integration.id}
            className={cn(
              "bg-[var(--color-ts-surface)] border rounded-2xl p-6 shadow-card transition-all",
              integration.status === "connected"
                ? "border-[var(--color-ts-border-light)]"
                : "border-[var(--color-ts-border)]"
            )}
          >
            <div className="flex items-start gap-4">
              {/* Icon */}
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0 border"
                style={{ backgroundColor: `${integration.color}15`, borderColor: `${integration.color}30` }}
              >
                {integration.icon}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-1 flex-wrap">
                  <h3 className="font-serif text-lg font-medium text-white">{integration.name}</h3>
                  <StatusBadge status={integration.status} />
                </div>
                <p className="text-sm text-[var(--color-ts-muted)] leading-relaxed mb-4">
                  {integration.description}
                </p>

                {/* Connected details */}
                {integration.status === "connected" && (
                  <div className="grid sm:grid-cols-3 gap-3 mb-4">
                    {integration.storeUrl && (
                      <div className="bg-[var(--color-ts-surface-2)] rounded-xl p-3 border border-[var(--color-ts-border)]">
                        <div className="text-xs text-[var(--color-ts-muted)] mb-1">Store URL</div>
                        <div className="text-sm text-white truncate">{integration.storeUrl}</div>
                      </div>
                    )}
                    {integration.lastSync && (
                      <div className="bg-[var(--color-ts-surface-2)] rounded-xl p-3 border border-[var(--color-ts-border)]">
                        <div className="text-xs text-[var(--color-ts-muted)] mb-1">Last Sync</div>
                        <div className="text-sm text-white">{integration.lastSync}</div>
                      </div>
                    )}
                    {integration.webhookStatus && (
                      <div className="bg-[var(--color-ts-surface-2)] rounded-xl p-3 border border-[var(--color-ts-border)]">
                        <div className="text-xs text-[var(--color-ts-muted)] mb-1">Webhooks</div>
                        <div className="flex items-center gap-1.5">
                          <div className={cn("w-2 h-2 rounded-full", integration.webhookStatus === "active" ? "bg-green-400" : "bg-red-400")} />
                          <span className="text-sm text-white capitalize">{integration.webhookStatus}</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Setup steps (disconnected) */}
                {integration.status === "disconnected" && (
                  <div className="space-y-1.5 mb-4">
                    {integration.setupSteps.map((step, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs text-[var(--color-ts-muted)]">
                        <span className="w-4 h-4 rounded-full bg-[var(--color-ts-surface-2)] border border-[var(--color-ts-border)] flex items-center justify-center text-[10px] shrink-0 mt-0.5">
                          {i + 1}
                        </span>
                        {step}
                      </div>
                    ))}
                  </div>
                )}

                {/* Actions */}
                <div className="flex flex-wrap gap-2">
                  {integration.status === "connected" ? (
                    <>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSync(integration.id)}
                        disabled={syncing === integration.id}
                        className="border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:text-white text-xs"
                      >
                        <RefreshCw className={cn("w-3.5 h-3.5 mr-1.5", syncing === integration.id && "animate-spin")} />
                        {syncing === integration.id ? "Syncing…" : "Sync Products"}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDisconnect(integration.id)}
                        className="border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:text-red-400 hover:border-red-500/30 text-xs"
                      >
                        Disconnect
                      </Button>
                    </>
                  ) : (
                    <Button
                      size="sm"
                      onClick={() => setSetupOpen(integration)}
                      className="bg-gradient-brand text-white hover:opacity-90 text-xs shadow-glow-blue"
                    >
                      <Plug className="w-3.5 h-3.5 mr-1.5" />
                      Connect {integration.name}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* API Key section */}
      <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-6 shadow-card space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[var(--color-ts-blue)]/10 border border-[var(--color-ts-blue)]/20 flex items-center justify-center">
            <Code2 className="w-5 h-5 text-[var(--color-ts-blue-light)]" />
          </div>
          <div>
            <h3 className="font-serif text-lg font-medium text-white">API Credentials</h3>
            <p className="text-xs text-[var(--color-ts-muted)]">Use these credentials for the Custom API integration</p>
          </div>
        </div>
        <div>
          <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">API Key</Label>
          <div className="flex gap-2">
            <Input
              value={DEMO_API_KEY}
              readOnly
              className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-[var(--color-ts-muted)] font-mono text-xs"
            />
            <Button variant="outline" size="sm" onClick={copyApiKey} className="border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:text-white shrink-0">
              {apiKeyCopied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
        </div>
        <div>
          <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Webhook Endpoint</Label>
          <Input
            value="https://api.trendset.io/webhooks/v1/events"
            readOnly
            className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-[var(--color-ts-muted)] font-mono text-xs"
          />
        </div>
        <div className="flex items-start gap-2 p-3 rounded-lg bg-[var(--color-ts-blue)]/5 border border-[var(--color-ts-blue)]/15">
          <AlertCircle className="w-4 h-4 text-[var(--color-ts-blue-light)] shrink-0 mt-0.5" />
          <p className="text-xs text-[var(--color-ts-muted)]">
            Keep your API key secret. Never expose it in client-side code. Use environment variables on your server.
          </p>
        </div>
      </div>

      {/* Setup Dialog */}
      {setupOpen && (
        <Dialog open={!!setupOpen} onOpenChange={() => setSetupOpen(null)}>
          <DialogContent className="bg-[var(--color-ts-surface)] border-[var(--color-ts-border)] text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="font-serif text-xl font-medium flex items-center gap-3">
                <span className="text-2xl">{setupOpen.icon}</span>
                Connect {setupOpen.name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <p className="text-sm text-[var(--color-ts-muted)]">
                Follow these steps to connect your {setupOpen.name} store:
              </p>
              <div className="space-y-2">
                {setupOpen.setupSteps.map((step, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-[var(--color-ts-surface-2)] border border-[var(--color-ts-border)]">
                    <span className="w-5 h-5 rounded-full bg-gradient-brand flex items-center justify-center text-[10px] text-white shrink-0 mt-0.5">
                      {i + 1}
                    </span>
                    <span className="text-sm text-[var(--color-ts-muted)]">{step}</span>
                  </div>
                ))}
              </div>
              <div className="flex items-start gap-2 p-3 rounded-lg bg-[var(--color-ts-violet)]/5 border border-[var(--color-ts-violet)]/15">
                <Zap className="w-4 h-4 text-[var(--color-ts-violet-light)] shrink-0 mt-0.5" />
                <p className="text-xs text-[var(--color-ts-muted)]">
                  In demo mode, clicking "Connect" will simulate a successful connection.
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setSetupOpen(null)} className="text-[var(--color-ts-muted)]">Cancel</Button>
              <Button onClick={() => handleConnect(setupOpen.id)} className="bg-gradient-brand text-white hover:opacity-90">
                Connect {setupOpen.name}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
