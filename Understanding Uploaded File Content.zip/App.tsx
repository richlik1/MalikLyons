import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, Redirect } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useAuth } from "./_core/hooks/useAuth";

// Public pages
import LandingPage from "./pages/LandingPage";
// Dashboard pages
import DashboardOverview from "./pages/dashboard/Overview";
import DashboardProducts from "./pages/dashboard/Products";
import DashboardTryOnStudio from "./pages/dashboard/TryOnStudio";
import DashboardWidgetCustomization from "./pages/dashboard/WidgetCustomization";
import DashboardAnalytics from "./pages/dashboard/Analytics";
import DashboardIntegrations from "./pages/dashboard/Integrations";
// Onboarding
import OnboardingWizard from "./pages/OnboardingWizard";
// Layout
import DashboardShell from "./components/DashboardShell";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, loading } = useAuth();
  if (loading) return null;
  if (!isAuthenticated) return <Redirect to="/" />;
  return <Component />;
}

function Router() {
  return (
    <Switch>
      {/* Public */}
      <Route path="/" component={LandingPage} />
      {/* Onboarding */}
      <Route path="/onboarding">
        {() => <ProtectedRoute component={OnboardingWizard} />}
      </Route>
      {/* Dashboard — wrapped in shell */}
      <Route path="/dashboard">
        {() => <ProtectedRoute component={() => <DashboardShell><DashboardOverview /></DashboardShell>} />}
      </Route>
      <Route path="/dashboard/products">
        {() => <ProtectedRoute component={() => <DashboardShell><DashboardProducts /></DashboardShell>} />}
      </Route>
      <Route path="/dashboard/studio">
        {() => <ProtectedRoute component={() => <DashboardShell><DashboardTryOnStudio /></DashboardShell>} />}
      </Route>
      <Route path="/dashboard/widget">
        {() => <ProtectedRoute component={() => <DashboardShell><DashboardWidgetCustomization /></DashboardShell>} />}
      </Route>
      <Route path="/dashboard/analytics">
        {() => <ProtectedRoute component={() => <DashboardShell><DashboardAnalytics /></DashboardShell>} />}
      </Route>
      <Route path="/dashboard/integrations">
        {() => <ProtectedRoute component={() => <DashboardShell><DashboardIntegrations /></DashboardShell>} />}
      </Route>
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster richColors position="top-right" />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
