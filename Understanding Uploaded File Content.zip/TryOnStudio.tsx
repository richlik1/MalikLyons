import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Upload, Wand2, Save, Trash2, RefreshCw, ChevronLeft, ChevronRight, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const PRODUCTS = [
  { id: 1, name: "Silk Wrap Dress",    emoji: "👗", colors: ["Ocean Blue", "Ivory", "Blush", "Emerald"] },
  { id: 2, name: "Linen Blazer",       emoji: "🧥", colors: ["Camel", "Navy", "Ivory", "Charcoal"] },
  { id: 4, name: "Wide-Leg Trousers",  emoji: "👖", colors: ["Ivory", "Caramel", "Black", "Sage"] },
  { id: 6, name: "Floral Midi Skirt",  emoji: "👘", colors: ["Blush Multi", "Blue Multi", "Neutral"] },
  { id: 9, name: "Ribbed Turtleneck",  emoji: "👕", colors: ["Cream", "Black", "Dusty Rose", "Forest"] },
  { id: 12, name: "Oversized Shirt",   emoji: "👔", colors: ["White", "Blue Stripe", "Pink", "Sage"] },
];

const SIZES = ["XS", "S", "M", "L", "XL", "XXL"];

const GENERATED_LOOKS = [
  { id: 1, product: "Silk Wrap Dress",   color: "Ocean Blue", size: "M", time: "2 hours ago" },
  { id: 2, product: "Linen Blazer",      color: "Camel",      size: "S", time: "Yesterday" },
  { id: 3, product: "Wide-Leg Trousers", color: "Ivory",      size: "M", time: "2 days ago" },
];

export default function TryOnStudio() {
  const [selectedProduct, setSelectedProduct] = useState(PRODUCTS[0]);
  const [selectedColor, setSelectedColor] = useState(PRODUCTS[0].colors[0]);
  const [selectedSize, setSelectedSize] = useState("M");
  const [height, setHeight] = useState("5'6\"");
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [generated, setGenerated] = useState(false);
  const [sliderPos, setSliderPos] = useState(50);
  const [savedLooks, setSavedLooks] = useState(GENERATED_LOOKS);
  const [deleteLookId, setDeleteLookId] = useState<number | null>(null);
  const [consentGiven, setConsentGiven] = useState(false);

  const handleGenerate = () => {
    if (!consentGiven) {
      toast.error("Please provide consent before uploading a photo.");
      return;
    }
    setGenerating(true);
    setProgress(0);
    setGenerated(false);
    let p = 0;
    const steps = [
      { msg: "Analyzing garment…",    target: 25 },
      { msg: "Processing body data…", target: 55 },
      { msg: "Rendering try-on…",     target: 85 },
      { msg: "Finalizing preview…",   target: 100 },
    ];
    let stepIdx = 0;
    const t = setInterval(() => {
      const step = steps[stepIdx];
      if (!step) { clearInterval(t); setGenerating(false); setGenerated(true); return; }
      p += 4;
      setProgress(Math.min(p, step.target));
      if (p >= step.target) { stepIdx++; }
    }, 80);
  };

  const handleSave = () => {
    const newLook = {
      id: Date.now(),
      product: selectedProduct.name,
      color: selectedColor,
      size: selectedSize,
      time: "Just now",
    };
    setSavedLooks((prev) => [newLook, ...prev]);
    toast.success("Look saved to your library");
  };

  const handleDelete = (id: number) => {
    setSavedLooks((prev) => prev.filter((l) => l.id !== id));
    toast.success("Look deleted");
  };

  const progressLabel =
    progress < 25 ? "Analyzing garment…" :
    progress < 55 ? "Processing body data…" :
    progress < 85 ? "Rendering try-on…" :
                    "Finalizing preview…";

  return (
    <div className="p-6 lg:p-8 space-y-6">
      <div>
        <h1 className="font-serif text-3xl font-light text-white">Try-On Studio</h1>
        <p className="text-sm text-[var(--color-ts-muted)] mt-1">Generate virtual try-on previews for your products</p>
      </div>

      <div className="grid lg:grid-cols-5 gap-6">
        {/* Controls — left */}
        <div className="lg:col-span-2 space-y-5">
          {/* Product selector */}
          <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-5 shadow-card space-y-4">
            <h3 className="font-serif text-base font-medium text-white">Select Product</h3>
            <div className="grid grid-cols-2 gap-2">
              {PRODUCTS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => { setSelectedProduct(p); setSelectedColor(p.colors[0]); setGenerated(false); }}
                  className={cn(
                    "flex items-center gap-2 p-2.5 rounded-xl border text-left text-sm transition-all",
                    selectedProduct.id === p.id
                      ? "border-[var(--color-ts-blue)]/50 bg-[var(--color-ts-blue)]/10 text-white"
                      : "border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:border-[var(--color-ts-border-light)]"
                  )}
                >
                  <span className="text-lg">{p.emoji}</span>
                  <span className="truncate text-xs">{p.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Variant + size */}
          <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-5 shadow-card space-y-4">
            <h3 className="font-serif text-base font-medium text-white">Garment Options</h3>
            <div>
              <Label className="text-xs text-[var(--color-ts-muted)] mb-2 block">Color</Label>
              <div className="flex flex-wrap gap-2">
                {selectedProduct.colors.map((c) => (
                  <button
                    key={c}
                    onClick={() => { setSelectedColor(c); setGenerated(false); }}
                    className={cn(
                      "px-2.5 py-1 rounded-lg text-xs border transition-all",
                      selectedColor === c
                        ? "border-[var(--color-ts-blue)]/50 bg-[var(--color-ts-blue)]/10 text-white"
                        : "border-[var(--color-ts-border)] text-[var(--color-ts-muted)]"
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-xs text-[var(--color-ts-muted)] mb-2 block">Size</Label>
              <div className="flex gap-2">
                {SIZES.map((s) => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={cn(
                      "w-9 h-9 rounded-lg text-xs border font-medium transition-all",
                      selectedSize === s
                        ? "border-[var(--color-ts-blue)]/50 bg-[var(--color-ts-blue)]/10 text-white"
                        : "border-[var(--color-ts-border)] text-[var(--color-ts-muted)]"
                    )}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Body info */}
          <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-5 shadow-card space-y-4">
            <h3 className="font-serif text-base font-medium text-white">Body Information</h3>
            <div>
              <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Height</Label>
              <Input
                value={height}
                onChange={(e) => setHeight(e.target.value)}
                className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white"
              />
            </div>
            <div>
              <Label className="text-xs text-[var(--color-ts-muted)] mb-2 block">Fit Preference</Label>
              <Select defaultValue="regular">
                <SelectTrigger className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)]">
                  <SelectItem value="slim" className="text-white">Slim fit</SelectItem>
                  <SelectItem value="regular" className="text-white">Regular fit</SelectItem>
                  <SelectItem value="relaxed" className="text-white">Relaxed fit</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Preview — right */}
        <div className="lg:col-span-3 space-y-5">
          {/* Upload + consent */}
          <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-5 shadow-card space-y-4">
            <h3 className="font-serif text-base font-medium text-white">Model Photo</h3>
            <div className="flex items-start gap-2 p-3 rounded-lg bg-[var(--color-ts-blue)]/5 border border-[var(--color-ts-blue)]/15">
              <AlertCircle className="w-4 h-4 text-[var(--color-ts-blue-light)] shrink-0 mt-0.5" />
              <p className="text-xs text-[var(--color-ts-muted)]">
                This is a style visualization tool. Results are illustrative and do not guarantee exact fit or appearance.
                Photos are processed ephemerally and not stored without consent.
              </p>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={consentGiven}
                onChange={(e) => setConsentGiven(e.target.checked)}
                className="w-4 h-4 rounded accent-[var(--color-ts-blue)]"
              />
              <span className="text-xs text-[var(--color-ts-muted)]">
                I consent to my photo being processed for this try-on session
              </span>
            </label>
            <div className="border-2 border-dashed border-[var(--color-ts-border)] rounded-xl p-8 text-center hover:border-[var(--color-ts-blue)]/30 transition-colors cursor-pointer">
              <Upload className="w-8 h-8 text-[var(--color-ts-muted)] mx-auto mb-3" />
              <p className="text-sm text-[var(--color-ts-muted)]">Upload a full-body photo</p>
              <p className="text-xs text-[var(--color-ts-muted-2)] mt-1">Stand straight, arms slightly away from body</p>
              <Button size="sm" className="mt-4 bg-[var(--color-ts-surface-2)] border border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:text-white text-xs">
                Choose File
              </Button>
            </div>
            <Button
              onClick={handleGenerate}
              disabled={generating}
              className="w-full bg-gradient-brand text-white hover:opacity-90 shadow-glow-blue"
            >
              <Wand2 className="w-4 h-4 mr-2" />
              {generating ? "Generating…" : "Generate Preview"}
            </Button>
            {generating && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-[var(--color-ts-muted)]">
                  <span>{progressLabel}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-1.5 bg-[var(--color-ts-surface-2)]" />
              </div>
            )}
          </div>

          {/* Before / After */}
          {generated && (
            <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-5 shadow-card space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-serif text-base font-medium text-white">Style Visualization</h3>
                <Badge className="bg-[var(--color-ts-violet)]/10 text-[var(--color-ts-violet-light)] border-[var(--color-ts-violet)]/20 text-xs">
                  Illustrative only
                </Badge>
              </div>
              {/* Comparison slider */}
              <div className="relative h-72 rounded-xl overflow-hidden bg-[var(--color-ts-surface-2)] border border-[var(--color-ts-border)] select-none">
                {/* Before */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <div className="text-5xl">🧍</div>
                    <div className="text-xs text-[var(--color-ts-muted)]">Before</div>
                  </div>
                </div>
                {/* After overlay */}
                <div
                  className="absolute inset-y-0 right-0 flex items-center justify-center bg-[var(--color-ts-surface-3)] border-l-2 border-[var(--color-ts-blue)]"
                  style={{ left: `${sliderPos}%` }}
                >
                  <div className="text-center space-y-2">
                    <div className="text-5xl">{selectedProduct.emoji}</div>
                    <div className="text-xs text-[var(--color-ts-muted)]">After — {selectedColor}</div>
                  </div>
                </div>
                {/* Slider handle */}
                <div
                  className="absolute inset-y-0 flex items-center cursor-ew-resize z-10"
                  style={{ left: `${sliderPos}%`, transform: "translateX(-50%)" }}
                  onMouseDown={(e) => {
                    const rect = e.currentTarget.parentElement!.getBoundingClientRect();
                    const move = (ev: MouseEvent) => {
                      const pct = Math.max(10, Math.min(90, ((ev.clientX - rect.left) / rect.width) * 100));
                      setSliderPos(pct);
                    };
                    const up = () => { window.removeEventListener("mousemove", move); window.removeEventListener("mouseup", up); };
                    window.addEventListener("mousemove", move);
                    window.addEventListener("mouseup", up);
                  }}
                >
                  <div className="w-8 h-8 rounded-full bg-white shadow-elevated flex items-center justify-center">
                    <ChevronLeft className="w-3 h-3 text-gray-600" />
                    <ChevronRight className="w-3 h-3 text-gray-600" />
                  </div>
                </div>
              </div>
              <div className="flex gap-3">
                <Button onClick={handleSave} className="flex-1 bg-gradient-brand text-white hover:opacity-90">
                  <Save className="w-4 h-4 mr-2" />
                  Save Look
                </Button>
                <Button variant="outline" onClick={() => setGenerated(false)} className="border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:text-white">
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Saved looks */}
          {savedLooks.length > 0 && (
            <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-5 shadow-card space-y-4">
              <h3 className="font-serif text-base font-medium text-white">Saved Looks</h3>
              <div className="space-y-2">
                {savedLooks.map((look) => (
                  <div key={look.id} className="flex items-center gap-3 p-3 rounded-xl bg-[var(--color-ts-surface-2)] border border-[var(--color-ts-border)]">
                    <div className="w-9 h-9 rounded-lg bg-[var(--color-ts-surface-3)] flex items-center justify-center text-lg border border-[var(--color-ts-border)]">
                      👗
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-white truncate">{look.product}</div>
                      <div className="text-xs text-[var(--color-ts-muted)]">{look.color} · Size {look.size} · {look.time}</div>
                    </div>
                    <button
                      onClick={() => handleDelete(look.id)}
                      className="p-1.5 rounded-lg text-[var(--color-ts-muted)] hover:text-red-400 hover:bg-red-500/10 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
