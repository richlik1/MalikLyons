import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import {
  organizations, stores, products, productVariants,
  widgetSettings, tryOnSessions, analyticsEvents, subscriptions,
} from "../../drizzle/schema";
import { eq } from "drizzle-orm";

const DEMO_ORG_ID = 1;

const DEMO_PRODUCTS = [
  { name: "Silk Wrap Dress",      vendor: "Lumière", category: "Dresses",   price: "189.00", tryOnEnabled: true },
  { name: "Linen Blazer",         vendor: "Lumière", category: "Outerwear", price: "245.00", tryOnEnabled: true },
  { name: "Cashmere Sweater",     vendor: "Lumière", category: "Tops",      price: "165.00", tryOnEnabled: false },
  { name: "Wide-Leg Trousers",    vendor: "Lumière", category: "Bottoms",   price: "135.00", tryOnEnabled: true },
  { name: "Knit Cardigan",        vendor: "Lumière", category: "Tops",      price: "120.00", tryOnEnabled: false },
  { name: "Floral Midi Skirt",    vendor: "Lumière", category: "Bottoms",   price: "98.00",  tryOnEnabled: true },
  { name: "Satin Slip Dress",     vendor: "Lumière", category: "Dresses",   price: "210.00", tryOnEnabled: true },
  { name: "Cropped Trench Coat",  vendor: "Lumière", category: "Outerwear", price: "320.00", tryOnEnabled: false },
  { name: "Ribbed Turtleneck",    vendor: "Lumière", category: "Tops",      price: "89.00",  tryOnEnabled: true },
  { name: "Pleated Midi Dress",   vendor: "Lumière", category: "Dresses",   price: "175.00", tryOnEnabled: false },
  { name: "Tailored Shorts",      vendor: "Lumière", category: "Bottoms",   price: "95.00",  tryOnEnabled: false },
  { name: "Oversized Shirt",      vendor: "Lumière", category: "Tops",      price: "110.00", tryOnEnabled: true },
];

export const demoRouter = router({
  /** Seed the demo organization, store, products, and analytics */
  seed: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    // Upsert demo org
    await db.insert(organizations).values({
      id: DEMO_ORG_ID,
      name: "Lumière Boutique (Demo)",
      slug: "lumiere-demo",
      plan: "growth",
      ownerId: ctx.user.id,
    }).onDuplicateKeyUpdate({ set: { name: "Lumière Boutique (Demo)" } });

    // Upsert demo store
    await db.insert(stores).values({
      id: 1,
      organizationId: DEMO_ORG_ID,
      platform: "shopify",
      name: "Lumière Boutique",
      url: "lumiere-boutique.myshopify.com",
      isConnected: true,
    }).onDuplicateKeyUpdate({ set: { isConnected: true } });

    // Upsert widget settings
    await db.insert(widgetSettings).values({
      organizationId: DEMO_ORG_ID,
      buttonText: "Try It On",
      buttonColor: "#3B82F6",
      isPublished: true,
    }).onDuplicateKeyUpdate({ set: { isPublished: true } });

    // Upsert subscription
    const periodEnd = new Date();
    periodEnd.setMonth(periodEnd.getMonth() + 1);
    await db.insert(subscriptions).values({
      organizationId: DEMO_ORG_ID,
      plan: "growth",
      status: "active",
      sessionsIncluded: 5000,
      sessionsUsed: 1725,
      currentPeriodEnd: periodEnd,
    }).onDuplicateKeyUpdate({ set: { sessionsUsed: 1725 } });

    // Upsert products
    for (let i = 0; i < DEMO_PRODUCTS.length; i++) {
      const p = DEMO_PRODUCTS[i];
      await db.insert(products).values({
        id: i + 1,
        organizationId: DEMO_ORG_ID,
        storeId: 1,
        externalId: `shopify_${i + 1}`,
        name: p.name,
        vendor: p.vendor,
        category: p.category,
        price: p.price as any,
        tryOnEnabled: p.tryOnEnabled,
      }).onDuplicateKeyUpdate({ set: { name: p.name, tryOnEnabled: p.tryOnEnabled } });
    }

    return { success: true, message: "Demo data seeded successfully" };
  }),

  /** Reset demo data to initial state */
  reset: protectedProcedure.mutation(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    // Clear analytics events for demo org
    await db.delete(analyticsEvents).where(eq(analyticsEvents.organizationId, DEMO_ORG_ID));
    // Clear try-on sessions for demo org
    await db.delete(tryOnSessions).where(eq(tryOnSessions.organizationId, DEMO_ORG_ID));
    // Reset subscription usage
    await db.update(subscriptions)
      .set({ sessionsUsed: 0 })
      .where(eq(subscriptions.organizationId, DEMO_ORG_ID));
    // Reset widget to defaults
    await db.update(widgetSettings)
      .set({ buttonText: "Try It On", buttonColor: "#3B82F6", isPublished: false })
      .where(eq(widgetSettings.organizationId, DEMO_ORG_ID));
    // Reset products try-on to defaults
    for (let i = 0; i < DEMO_PRODUCTS.length; i++) {
      await db.update(products)
        .set({ tryOnEnabled: DEMO_PRODUCTS[i].tryOnEnabled })
        .where(eq(products.id, i + 1));
    }

    return { success: true, message: "Demo data reset to initial state" };
  }),

  /** Get demo analytics summary */
  analytics: publicProcedure.query(async () => {
    return {
      totalSessions: 1725,
      conversionRate: 23.8,
      revenueLift: 14200,
      activeProducts: 8,
      topProducts: DEMO_PRODUCTS.filter((p) => p.tryOnEnabled).slice(0, 5).map((p, i) => ({
        name: p.name,
        sessions: [312, 241, 198, 167, 143][i] ?? 100,
        revenue: ["$4,820", "$3,610", "$2,940", "$2,180", "$1,920"][i] ?? "$1,000",
      })),
    };
  }),
});
