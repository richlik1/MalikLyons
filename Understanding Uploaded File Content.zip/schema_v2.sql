-- Provider Management
CREATE TABLE IF NOT EXISTS `try_on_providers` (
  `id` int AUTO_INCREMENT NOT NULL,
  `name` varchar(128) NOT NULL UNIQUE,
  `description` text,
  `status` enum('active','inactive','maintenance','deprecated') NOT NULL DEFAULT 'active',
  `supportedCategories` json,
  `estimatedCost` decimal(10,4),
  `expectedGenerationTime` int,
  `qualityRating` decimal(3,2),
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `try_on_providers_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `provider_capabilities` (
  `id` int AUTO_INCREMENT NOT NULL,
  `providerId` int NOT NULL,
  `category` varchar(128) NOT NULL,
  `supportedVariants` json,
  `maxImageSize` int,
  `supportedFormats` json,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `provider_capabilities_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `provider_health` (
  `id` int AUTO_INCREMENT NOT NULL,
  `providerId` int NOT NULL,
  `successRate` decimal(5,2),
  `averageGenerationTime` int,
  `lastHealthCheck` timestamp,
  `status` enum('healthy','degraded','down') NOT NULL DEFAULT 'healthy',
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `provider_health_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `provider_requests` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `providerId` int NOT NULL,
  `tryOnRequestId` int,
  `status` enum('pending','processing','completed','failed','retry') NOT NULL DEFAULT 'pending',
  `requestPayload` json,
  `responsePayload` json,
  `errorMessage` text,
  `retryCount` int DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `completedAt` timestamp,
  CONSTRAINT `provider_requests_id` PRIMARY KEY(`id`)
);

-- Quality Evaluation
CREATE TABLE IF NOT EXISTS `quality_evaluations` (
  `id` int AUTO_INCREMENT NOT NULL,
  `tryOnResultId` int NOT NULL,
  `facePreservation` decimal(3,2),
  `bodyPreservation` decimal(3,2),
  `garmentColorAccuracy` decimal(3,2),
  `patternPreservation` decimal(3,2),
  `logoPreservation` decimal(3,2),
  `silhouetteAccuracy` decimal(3,2),
  `limbArtifacts` decimal(3,2),
  `occlusionQuality` decimal(3,2),
  `backgroundPreservation` decimal(3,2),
  `overallPhotorealism` decimal(3,2),
  `merchantApproval` boolean,
  `shopperApproval` boolean,
  `overallScore` decimal(3,2),
  `evaluatedBy` int,
  `evaluatedAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `quality_evaluations_id` PRIMARY KEY(`id`)
);

-- Garment Data Standard
CREATE TABLE IF NOT EXISTS `garment_records` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `productId` int NOT NULL,
  `merchantProductId` varchar(128),
  `title` varchar(255) NOT NULL,
  `brand` varchar(128),
  `category` varchar(128) NOT NULL,
  `subcategory` varchar(128),
  `garmentType` varchar(128),
  `silhouette` varchar(128),
  `fabricComposition` text,
  `stretchLevel` enum('none','low','medium','high') DEFAULT 'medium',
  `opacity` enum('opaque','translucent','sheer') DEFAULT 'opaque',
  `weight` varchar(64),
  `fitDescription` text,
  `closureType` varchar(128),
  `careInstructions` text,
  `frontImageKey` text,
  `backImageKey` text,
  `flatLayImageKey` text,
  `modelImageKey` text,
  `detailImageKeys` json,
  `modelMeasurements` json,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `garment_records_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `size_charts` (
  `id` int AUTO_INCREMENT NOT NULL,
  `garmentRecordId` int NOT NULL,
  `size` varchar(32) NOT NULL,
  `bust` decimal(6,2),
  `waist` decimal(6,2),
  `hips` decimal(6,2),
  `length` decimal(6,2),
  `sleeve` decimal(6,2),
  `shoulder` decimal(6,2),
  `notes` text,
  CONSTRAINT `size_charts_id` PRIMARY KEY(`id`)
);

-- Shopper Profiles & Measurements
CREATE TABLE IF NOT EXISTS `shopper_profiles` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `sessionToken` varchar(128) UNIQUE,
  `height` varchar(32),
  `weightRange` varchar(32),
  `usualTopSize` varchar(32),
  `usualBottomSize` varchar(32),
  `fitPreference` varchar(128),
  `preferredBrands` json,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `shopper_profiles_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `shopper_measurements` (
  `id` int AUTO_INCREMENT NOT NULL,
  `shopperProfileId` int NOT NULL,
  `chest` decimal(6,2),
  `waist` decimal(6,2),
  `hips` decimal(6,2),
  `inseam` decimal(6,2),
  `recordedAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `shopper_measurements_id` PRIMARY KEY(`id`)
);

-- Try-On Flow (Renamed from try_on_sessions)
CREATE TABLE IF NOT EXISTS `try_on_requests` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `productId` int,
  `variantId` int,
  `shopperProfileId` int,
  `sessionToken` varchar(128) NOT NULL UNIQUE,
  `status` enum('initiated','photo_uploaded','generation_started','generation_completed','result_accepted','result_regenerated','result_saved','result_shared','abandoned') NOT NULL DEFAULT 'initiated',
  `photoConsent` boolean NOT NULL DEFAULT false,
  `photoUploadedAt` timestamp,
  `generationStartedAt` timestamp,
  `generationCompletedAt` timestamp,
  `resultAcceptedAt` timestamp,
  `photoDeletedAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `try_on_requests_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `try_on_results` (
  `id` int AUTO_INCREMENT NOT NULL,
  `tryOnRequestId` int NOT NULL,
  `productId` int NOT NULL,
  `variantId` int,
  `selectedColor` varchar(128),
  `selectedSize` varchar(32),
  `generatedImageKey` text,
  `generatedImageUrl` text,
  `originalPhotoKey` text,
  `qualityScore` decimal(3,2),
  `productFidelityScore` decimal(3,2),
  `identityPreservationScore` decimal(3,2),
  `warnings` json,
  `isDeleted` boolean NOT NULL DEFAULT false,
  `deletedAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `try_on_results_id` PRIMARY KEY(`id`)
);

-- Fit Recommendations
CREATE TABLE IF NOT EXISTS `fit_recommendations` (
  `id` int AUTO_INCREMENT NOT NULL,
  `tryOnRequestId` int NOT NULL,
  `garmentRecordId` int NOT NULL,
  `recommendedSize` varchar(32),
  `alternativeSize` varchar(32),
  `confidencePercentage` int,
  `fitNotes` text,
  `explanation` text,
  `feedbackRequested` boolean DEFAULT true,
  `shopperFeedback` enum('fits_well','too_small','too_large','other'),
  `feedbackProvidedAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `fit_recommendations_id` PRIMARY KEY(`id`)
);

-- Commerce Tracking
CREATE TABLE IF NOT EXISTS `storefront_events` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `productId` int,
  `tryOnRequestId` int,
  `tryOnResultId` int,
  `eventType` enum('widget_view','try_on_open','photo_upload','generation_started','generation_completed','result_accepted','result_regenerated','result_saved','result_shared','size_selected','variant_selected','add_to_cart','checkout_started','purchase_completed','return_initiated','return_reason','size_exchange') NOT NULL,
  `metadata` json,
  `occurredAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `storefront_events_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `purchases` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `tryOnRequestId` int,
  `productId` int,
  `variantId` int,
  `selectedSize` varchar(32),
  `selectedColor` varchar(128),
  `orderValue` decimal(10,2),
  `usedTryOn` boolean NOT NULL DEFAULT false,
  `purchasedAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `purchases_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `returns` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `purchaseId` int,
  `tryOnRequestId` int,
  `productId` int,
  `reason` varchar(256),
  `reasonCategory` enum('wrong_size','wrong_color','quality','fit','changed_mind','other'),
  `sizeExchange` varchar(32),
  `returnedAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `returns_id` PRIMARY KEY(`id`)
);

-- Content Generation & Assets
CREATE TABLE IF NOT EXISTS `generated_assets` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `productId` int NOT NULL,
  `assetType` enum('on_model','lifestyle','multiple_body','flat_lay','detail') NOT NULL,
  `modelType` varchar(128),
  `imageKey` text,
  `imageUrl` text,
  `campaign` varchar(128),
  `approvalStatus` enum('pending','approved','rejected') DEFAULT 'pending',
  `approvedBy` int,
  `approvedAt` timestamp,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `generated_assets_id` PRIMARY KEY(`id`)
);

-- Pilot Program
CREATE TABLE IF NOT EXISTS `pilot_accounts` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL UNIQUE,
  `companyName` varchar(255) NOT NULL,
  `website` varchar(512),
  `ecommercePlatform` varchar(128),
  `monthlyWebsiteTraffic` int,
  `estimatedMonthlyRevenue` varchar(64),
  `productCategory` varchar(128),
  `numberOfProducts` int,
  `approximateReturnRate` decimal(5,2),
  `biggestProblem` text,
  `contactEmail` varchar(320),
  `contactPhone` varchar(32),
  `interestInPaidPilot` boolean,
  `applicationStatus` enum('pending','approved','rejected','active','completed') NOT NULL DEFAULT 'pending',
  `pilotStartDate` timestamp,
  `pilotEndDate` timestamp,
  `appliedAt` timestamp NOT NULL DEFAULT (now()),
  `approvedAt` timestamp,
  CONSTRAINT `pilot_accounts_id` PRIMARY KEY(`id`)
);

CREATE TABLE IF NOT EXISTS `pilot_feedback` (
  `id` int AUTO_INCREMENT NOT NULL,
  `pilotAccountId` int NOT NULL,
  `feedbackType` enum('merchant','shopper','weekly_summary') NOT NULL,
  `rating` int,
  `comment` text,
  `caseStudyData` json,
  `submittedAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `pilot_feedback_id` PRIMARY KEY(`id`)
);

-- Usage & Billing
CREATE TABLE IF NOT EXISTS `usage_records` (
  `id` int AUTO_INCREMENT NOT NULL,
  `organizationId` int NOT NULL,
  `billingPeriodStart` timestamp NOT NULL,
  `billingPeriodEnd` timestamp NOT NULL,
  `generationsRequested` int DEFAULT 0,
  `generationsCompleted` int DEFAULT 0,
  `estimatedGenerationCost` decimal(10,2),
  `eventsTracked` int DEFAULT 0,
  `storageUsedMb` int DEFAULT 0,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  CONSTRAINT `usage_records_id` PRIMARY KEY(`id`)
);
