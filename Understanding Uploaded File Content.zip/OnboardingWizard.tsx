import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import {
  Sparkles, Building2, Store, Link2, Download, Package, Sliders,
  Globe, CheckCircle2, ArrowRight, ArrowLeft, Zap, Check,
} from "lucide-react";

const TOTAL_STEPS = 9;

const STEP_META = [
  { icon: Building2, title: "Welcome",            subtitle: "Let's set up your store" },
  { icon: Store,     title: "Store Platform",     subtitle: "Choose your platform" },
  { icon: Link2,     title: "Connect Store",      subtitle: "Link your Shopify store" },
  { icon: Download,  title: "Import Products",    subtitle: "Sync your catalog" },
  { icon: Package,   title: "Select Products",    subtitle: "Enable try-on" },
  { icon: Sliders,   title: "Widget Design",      subtitle: "Customize appearance" },
  { icon: Globe,     title: "Publish Widget",     subtitle: "Go live" },
  { icon: Zap,       title: "Verify Integration", subtitle: "Test everything" },
  { icon: CheckCircle2, title: "You're Live!",    subtitle: "Setup complete" },
];

const DEMO_PRODUCTS = [
  { id: 1, name: "Silk Wrap Dress",    price: "$189", img: "👗", selected: true },
  { id: 2, name: "Linen Blazer",       price: "$245", img: "🧥", selected: true },
  { id: 3, name: "Cashmere Sweater",   price: "$165", img: "🧶", selected: false },
  { id: 4, name: "Wide-Leg Trousers",  price: "$135", img: "👖", selected: true },
  { id: 5, name: "Knit Cardigan",      price: "$120", img: "🧣", selected: false },
  { id: 6, name: "Floral Midi Skirt",  price: "$98",  img: "👘", selected: true },
];

export default function OnboardingWizard() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState(1);
  const [demoMode, setDemoMode] = useState(true);
  const [form, setForm] = useState({
    businessName: "",
    contactEmail: "",
    platform: "",
    shopifyUrl: "",
  });
  const [selectedProducts, setSelectedProducts] = useState<number[]>([1, 2, 4, 6]);
  const [widgetColor, setWidgetColor] = useState("#3B82F6");
  const [buttonText, setButtonText] = useState("Try It On");
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [publishing, setPublishing] = useState(false);
  const [published, setPublished] = useState(false);

  const progress = ((step - 1) / (TOTAL_STEPS - 1)) * 100;

  const next = () => {
    if (step === 4 && !importing && importProgress === 0) {
      setImporting(true);
      let p = 0;
      const t = setInterval(() => {
        p += Math.random() * 18 + 5;
        if (p >= 100) { p = 100; clearInterval(t); setImporting(false); setImportProgress(100); }
        setImportProgress(Math.min(p, 100));
      }, 300);
      return;
    }
    if (step === 7 && !published) {
      setPublishing(true);
      setTimeout(() => { setPublishing(false); setPublished(true); }, 1800);
      return;
    }
    if (step < TOTAL_STEPS) setStep(step + 1);
  };

  const back = () => { if (step > 1) setStep(step - 1); };

  const toggleProduct = (id: number) => {
    setSelectedProducts((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    );
  };

  const canProceed = () => {
    if (step === 1) return demoMode || (form.businessName.trim().length > 0);
    if (step === 2) return demoMode || form.platform !== "";
    if (step === 3) return demoMode || form.shopifyUrl.trim().length > 0;
    if (step === 4) return importProgress === 100;
    return true;
  };

  const meta = STEP_META[step - 1];
  const Icon = meta.icon;

  return (
    <div className="min-h-screen bg-[var(--color-background)] flex flex-col">
      {/* Header */}
      <header className="h-16 flex items-center justify-between px-6 border-b border-[var(--color-ts-border)]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-brand flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-serif text-lg font-semibold text-white">Trendset</span>
        </div>
        <div className="flex items-center gap-3">
          <Label htmlFor="demo-mode" className="text-xs text-[var(--color-ts-muted)]">Demo Mode</Label>
          <Switch
            id="demo-mode"
            checked={demoMode}
            onCheckedChange={setDemoMode}
            className="data-[state=checked]:bg-[var(--color-ts-blue)]"
          />
        </div>
      </header>

      {/* Progress bar */}
      <div className="px-6 pt-6">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-[var(--color-ts-muted)]">Step {step} of {TOTAL_STEPS}</span>
            <span className="text-xs text-[var(--color-ts-muted)]">{Math.round(progress)}% complete</span>
          </div>
          <Progress value={progress} className="h-1.5 bg-[var(--color-ts-surface-2)]" />
        </div>
      </div>

      {/* Step indicators */}
      <div className="px-6 pt-4 pb-2 overflow-x-auto">
        <div className="flex gap-1.5 max-w-2xl mx-auto min-w-max">
          {STEP_META.map((s, i) => {
            const StepIcon = s.icon;
            const n = i + 1;
            const done = n < step;
            const active = n === step;
            return (
              <div
                key={n}
                className={cn(
                  "flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs transition-all duration-200 shrink-0",
                  done   ? "bg-[var(--color-ts-blue)]/10 text-[var(--color-ts-blue-light)]" :
                  active ? "bg-[var(--color-ts-surface-2)] text-white border border-[var(--color-ts-border-light)]" :
                           "text-[var(--color-ts-muted-2)]"
                )}
              >
                {done
                  ? <Check className="w-3 h-3" />
                  : <StepIcon className="w-3 h-3" />
                }
                <span className="hidden sm:inline">{s.title}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex items-start justify-center px-6 py-8">
        <div className="w-full max-w-2xl">
          <div className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-8 shadow-elevated">
            {/* Step header */}
            <div className="flex items-start gap-4 mb-8">
              <div className="w-12 h-12 rounded-xl bg-gradient-brand/15 border border-[var(--color-ts-blue)]/20 flex items-center justify-center shrink-0">
                <Icon className="w-6 h-6 text-[var(--color-ts-blue-light)]" />
              </div>
              <div>
                <h2 className="font-serif text-2xl font-medium text-white">{meta.title}</h2>
                <p className="text-sm text-[var(--color-ts-muted)] mt-0.5">{meta.subtitle}</p>
              </div>
              {demoMode && (
                <Badge className="ml-auto bg-[var(--color-ts-violet)]/10 text-[var(--color-ts-violet-light)] border-[var(--color-ts-violet)]/20 text-xs shrink-0">
                  Demo Mode
                </Badge>
              )}
            </div>

            {/* Step body */}
            <div className="space-y-6">
              {/* Step 1 — Business info */}
              {step === 1 && (
                <div className="space-y-4">
                  <p className="text-sm text-[var(--color-ts-muted)]">
                    Welcome to Trendset. Let's get your virtual try-on experience set up.
                    {demoMode && " Demo mode is active — we'll pre-fill everything for you."}
                  </p>
                  <div className="space-y-3">
                    <div>
                      <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Business Name</Label>
                      <Input
                        value={demoMode ? "Lumière Boutique (Demo)" : form.businessName}
                        onChange={(e) => setForm({ ...form, businessName: e.target.value })}
                        disabled={demoMode}
                        placeholder="Your store name"
                        className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white placeholder:text-[var(--color-ts-muted-2)]"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Contact Email</Label>
                      <Input
                        value={demoMode ? "demo@lumiere.com" : form.contactEmail}
                        onChange={(e) => setForm({ ...form, contactEmail: e.target.value })}
                        disabled={demoMode}
                        placeholder="you@yourbrand.com"
                        className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white placeholder:text-[var(--color-ts-muted-2)]"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2 — Platform */}
              {step === 2 && (
                <div className="space-y-4">
                  <p className="text-sm text-[var(--color-ts-muted)]">Which e-commerce platform powers your store?</p>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: "shopify",     label: "Shopify",     emoji: "🛍️" },
                      { id: "woocommerce", label: "WooCommerce", emoji: "🔌" },
                      { id: "custom",      label: "Custom API",  emoji: "⚙️" },
                    ].map((p) => (
                      <button
                        key={p.id}
                        onClick={() => !demoMode && setForm({ ...form, platform: p.id })}
                        className={cn(
                          "p-4 rounded-xl border text-center transition-all duration-200",
                          (demoMode ? "shopify" : form.platform) === p.id
                            ? "border-[var(--color-ts-blue)]/50 bg-[var(--color-ts-blue)]/10 text-white"
                            : "border-[var(--color-ts-border)] text-[var(--color-ts-muted)] hover:border-[var(--color-ts-border-light)]"
                        )}
                      >
                        <div className="text-2xl mb-2">{p.emoji}</div>
                        <div className="text-sm font-medium">{p.label}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Step 3 — Connect store */}
              {step === 3 && (
                <div className="space-y-4">
                  <p className="text-sm text-[var(--color-ts-muted)]">
                    {demoMode
                      ? "In demo mode, we'll simulate a Shopify connection."
                      : "Enter your Shopify store URL to begin the OAuth connection."}
                  </p>
                  <div>
                    <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Shopify Store URL</Label>
                    <div className="flex gap-2">
                      <Input
                        value={demoMode ? "lumiere-boutique.myshopify.com" : form.shopifyUrl}
                        onChange={(e) => setForm({ ...form, shopifyUrl: e.target.value })}
                        disabled={demoMode}
                        placeholder="yourstore.myshopify.com"
                        className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white placeholder:text-[var(--color-ts-muted-2)]"
                      />
                      <Button
                        className="bg-gradient-brand text-white hover:opacity-90 shrink-0"
                        onClick={() => {}}
                      >
                        Connect
                      </Button>
                    </div>
                  </div>
                  {demoMode && (
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                      <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                      <span className="text-sm text-green-300">Demo store connected successfully</span>
                    </div>
                  )}
                </div>
              )}

              {/* Step 4 — Import products */}
              {step === 4 && (
                <div className="space-y-5">
                  <p className="text-sm text-[var(--color-ts-muted)]">
                    {demoMode ? "Importing demo product catalog…" : "Syncing products from your Shopify store."}
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-[var(--color-ts-muted)]">
                      <span>{importing ? "Importing…" : importProgress === 100 ? "Import complete" : "Ready to import"}</span>
                      <span>{Math.round(importProgress)}%</span>
                    </div>
                    <Progress value={importProgress} className="h-2 bg-[var(--color-ts-surface-2)]" />
                  </div>
                  {importProgress === 100 && (
                    <div className="grid grid-cols-2 gap-3">
                      {[["12", "Products imported"], ["36", "Variants synced"], ["12", "Images ready"], ["0", "Errors"]].map(([v, l]) => (
                        <div key={l} className="bg-[var(--color-ts-surface-2)] rounded-xl p-4 text-center">
                          <div className="font-serif text-2xl font-medium text-white">{v}</div>
                          <div className="text-xs text-[var(--color-ts-muted)] mt-1">{l}</div>
                        </div>
                      ))}
                    </div>
                  )}
                  {importProgress === 0 && !importing && (
                    <Button
                      onClick={next}
                      className="bg-gradient-brand text-white hover:opacity-90 w-full"
                    >
                      Start Import
                    </Button>
                  )}
                </div>
              )}

              {/* Step 5 — Select products */}
              {step === 5 && (
                <div className="space-y-4">
                  <p className="text-sm text-[var(--color-ts-muted)]">
                    Choose which products will have the virtual try-on widget enabled.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {DEMO_PRODUCTS.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => toggleProduct(p.id)}
                        className={cn(
                          "flex items-center gap-3 p-3 rounded-xl border text-left transition-all duration-200",
                          selectedProducts.includes(p.id)
                            ? "border-[var(--color-ts-blue)]/50 bg-[var(--color-ts-blue)]/10"
                            : "border-[var(--color-ts-border)] hover:border-[var(--color-ts-border-light)]"
                        )}
                      >
                        <span className="text-2xl">{p.img}</span>
                        <div className="min-w-0">
                          <div className="text-sm font-medium text-white truncate">{p.name}</div>
                          <div className="text-xs text-[var(--color-ts-muted)]">{p.price}</div>
                        </div>
                        {selectedProducts.includes(p.id) && (
                          <Check className="w-4 h-4 text-[var(--color-ts-blue-light)] ml-auto shrink-0" />
                        )}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-[var(--color-ts-muted)]">
                    {selectedProducts.length} of {DEMO_PRODUCTS.length} products selected
                  </p>
                </div>
              )}

              {/* Step 6 — Widget design */}
              {step === 6 && (
                <div className="space-y-5">
                  <p className="text-sm text-[var(--color-ts-muted)]">Customize the try-on widget to match your brand.</p>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Button Text</Label>
                        <Input
                          value={buttonText}
                          onChange={(e) => setButtonText(e.target.value)}
                          className="bg-[var(--color-ts-surface-2)] border-[var(--color-ts-border)] text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-xs text-[var(--color-ts-muted)] mb-1.5 block">Button Color</Label>
                        <div className="flex gap-2 flex-wrap">
                          {["#3B82F6", "#8B5CF6", "#EC4899", "#10B981", "#F59E0B"].map((c) => (
                            <button
                              key={c}
                              onClick={() => setWidgetColor(c)}
                              className={cn(
                                "w-8 h-8 rounded-lg border-2 transition-all",
                                widgetColor === c ? "border-white scale-110" : "border-transparent"
                              )}
                              style={{ backgroundColor: c }}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                    {/* Live preview */}
                    <div className="bg-[var(--color-ts-surface-2)] rounded-xl p-4 flex flex-col items-center justify-center gap-3 border border-[var(--color-ts-border)]">
                      <div className="text-xs text-[var(--color-ts-muted)] mb-1">Widget Preview</div>
                      <div className="w-32 h-40 rounded-lg bg-[var(--color-ts-surface-3)] flex items-center justify-center text-3xl">
                        👗
                      </div>
                      <button
                        className="px-4 py-2 rounded-lg text-white text-sm font-medium transition-all"
                        style={{ backgroundColor: widgetColor }}
                      >
                        {buttonText || "Try It On"}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 7 — Publish */}
              {step === 7 && (
                <div className="space-y-5">
                  <p className="text-sm text-[var(--color-ts-muted)]">
                    {published
                      ? "Your widget is live and ready for shoppers."
                      : "Publish the test widget to your storefront."}
                  </p>
                  {published ? (
                    <div className="flex items-center gap-3 p-4 rounded-xl bg-green-500/10 border border-green-500/20">
                      <CheckCircle2 className="w-6 h-6 text-green-400 shrink-0" />
                      <div>
                        <div className="text-sm font-medium text-green-300">Widget published successfully</div>
                        <div className="text-xs text-green-400/70 mt-0.5">
                          {demoMode ? "lumiere-boutique.myshopify.com" : form.shopifyUrl}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <Button
                      onClick={next}
                      disabled={publishing}
                      className="bg-gradient-brand text-white hover:opacity-90 w-full"
                    >
                      {publishing ? "Publishing…" : "Publish Test Widget"}
                    </Button>
                  )}
                  <div className="bg-[var(--color-ts-surface-2)] rounded-xl p-4 border border-[var(--color-ts-border)]">
                    <div className="text-xs text-[var(--color-ts-muted)] mb-2">Embed code</div>
                    <code className="text-xs text-[var(--color-ts-blue-light)] font-mono break-all">
                      {`<script src="https://cdn.trendset.io/widget.js" data-key="demo_key_xxx"></script>`}
                    </code>
                  </div>
                </div>
              )}

              {/* Step 8 — Verify */}
              {step === 8 && (
                <div className="space-y-4">
                  <p className="text-sm text-[var(--color-ts-muted)]">Verifying your integration is working correctly.</p>
                  <div className="space-y-2">
                    {[
                      ["Shopify connection", true],
                      ["Product sync", true],
                      ["Widget script loaded", true],
                      ["Analytics events firing", true],
                      ["Cart handoff", true],
                    ].map(([label, ok]) => (
                      <div key={label as string} className="flex items-center gap-3 p-3 rounded-lg bg-[var(--color-ts-surface-2)] border border-[var(--color-ts-border)]">
                        <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                        <span className="text-sm text-white">{label as string}</span>
                        <Badge className="ml-auto bg-green-500/10 text-green-400 border-green-500/20 text-xs">Pass</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Step 9 — Complete */}
              {step === 9 && (
                <div className="text-center space-y-6 py-4">
                  <div className="w-20 h-20 rounded-full bg-gradient-brand mx-auto flex items-center justify-center shadow-glow-blue">
                    <CheckCircle2 className="w-10 h-10 text-white" />
                  </div>
                  <div>
                    <h3 className="font-serif text-2xl font-medium text-white mb-2">You're all set!</h3>
                    <p className="text-sm text-[var(--color-ts-muted)]">
                      Your virtual try-on experience is live. Head to your dashboard to monitor sessions and analytics.
                    </p>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    {[["4", "Products live"], ["0", "Sessions today"], ["—", "Conversion rate"]].map(([v, l]) => (
                      <div key={l} className="bg-[var(--color-ts-surface-2)] rounded-xl p-4 text-center border border-[var(--color-ts-border)]">
                        <div className="font-serif text-2xl font-medium text-white">{v}</div>
                        <div className="text-xs text-[var(--color-ts-muted)] mt-1">{l}</div>
                      </div>
                    ))}
                  </div>
                  <Button
                    onClick={() => navigate("/dashboard")}
                    className="bg-gradient-brand text-white hover:opacity-90 px-8"
                  >
                    Go to Dashboard
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              )}
            </div>

            {/* Navigation */}
            {step !== 9 && (
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-[var(--color-ts-border)]">
                <Button
                  variant="ghost"
                  onClick={back}
                  disabled={step === 1}
                  className="text-[var(--color-ts-muted)] hover:text-white"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
                {step !== 4 && step !== 7 && (
                  <Button
                    onClick={next}
                    disabled={!canProceed()}
                    className="bg-gradient-brand text-white hover:opacity-90"
                  >
                    {step === 8 ? "Complete Setup" : "Continue"}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
                {step === 4 && importProgress === 100 && (
                  <Button
                    onClick={() => setStep(5)}
                    className="bg-gradient-brand text-white hover:opacity-90"
                  >
                    Continue
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
                {step === 7 && published && (
                  <Button
                    onClick={() => setStep(8)}
                    className="bg-gradient-brand text-white hover:opacity-90"
                  >
                    Continue
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
