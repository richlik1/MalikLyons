import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Sparkles, Zap, ShoppingBag, BarChart3, Shield, Plug, ArrowRight,
  Check, Star, ChevronDown, Menu, X, TrendingUp, Users, Package,
  Wand2, Eye, RefreshCw,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ─── Navigation ─────────────────────────────────────────────────────────── */
function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-[var(--color-ts-black)]/90 backdrop-blur-xl border-b border-[var(--color-ts-border)]"
          : "bg-transparent"
      )}
    >
      <div className="container flex items-center justify-between h-16">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-brand flex items-center justify-center shadow-glow-blue">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-serif text-lg font-semibold text-white tracking-tight">Trendset</span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {["Features", "How It Works", "Pricing"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(/ /g, "-")}`}
              className="text-sm text-[var(--color-ts-muted)] hover:text-white transition-colors"
            >
              {item}
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-3">
          {isAuthenticated ? (
            <Link href="/dashboard">
              <Button size="sm" className="bg-gradient-brand text-white hover:opacity-90 shadow-glow-blue">
                Dashboard <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Button>
            </Link>
          ) : (
            <>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => startLogin()}
                className="text-[var(--color-ts-muted)] hover:text-white"
              >
                Sign In
              </Button>
              <Button
                size="sm"
                onClick={() => startLogin()}
                className="bg-gradient-brand text-white hover:opacity-90 shadow-glow-blue"
              >
                Book a Demo
              </Button>
            </>
          )}
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-[var(--color-ts-muted)] hover:text-white"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden bg-[var(--color-ts-surface)] border-b border-[var(--color-ts-border)] px-6 py-4 space-y-3">
          {["Features", "How It Works", "Pricing"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(/ /g, "-")}`}
              className="block text-sm text-[var(--color-ts-muted)] hover:text-white"
              onClick={() => setMenuOpen(false)}
            >
              {item}
            </a>
          ))}
          <Button
            size="sm"
            onClick={() => startLogin()}
            className="w-full bg-gradient-brand text-white"
          >
            Get Started
          </Button>
        </div>
      )}
    </header>
  );
}

/* ─── Hero ───────────────────────────────────────────────────────────────── */
function Hero() {
  const [activeColor, setActiveColor] = useState(0);
  const colors = ["#3B82F6", "#8B5CF6", "#EC4899", "#10B981"];
  const colorNames = ["Ocean Blue", "Deep Violet", "Rose Pink", "Emerald"];

  useEffect(() => {
    const t = setInterval(() => setActiveColor((c) => (c + 1) % colors.length), 2000);
    return () => clearInterval(t);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full bg-[var(--color-ts-blue)]/8 blur-[120px] animate-pulse-slow" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 rounded-full bg-[var(--color-ts-violet)]/8 blur-[100px] animate-pulse-slow" style={{ animationDelay: "2s" }} />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,oklch(0.12_0.01_260)_0%,var(--color-background)_70%)]" />
      </div>

      <div className="container relative z-10 grid lg:grid-cols-2 gap-12 lg:gap-20 items-center py-20">
        {/* Left — copy */}
        <div className="space-y-8">
          <Badge className="inline-flex items-center gap-1.5 bg-[var(--color-ts-blue)]/10 text-[var(--color-ts-blue-light)] border-[var(--color-ts-blue)]/20 px-3 py-1.5 text-xs font-medium">
            <Sparkles className="w-3 h-3" />
            AI-Powered Virtual Try-On
          </Badge>

          <h1 className="font-serif text-5xl lg:text-7xl font-light text-white leading-[1.05] tracking-tight">
            Turn product photos into{" "}
            <span className="text-gradient-blue italic">personal fitting rooms.</span>
          </h1>

          <p className="text-lg text-[var(--color-ts-muted)] leading-relaxed max-w-lg">
            Trendset gives fashion retailers an AI-powered virtual try-on experience
            connected directly to their storefront — increasing confidence, reducing returns,
            and converting browsers into buyers.
          </p>

          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              onClick={() => startLogin()}
              className="bg-gradient-brand text-white hover:opacity-90 shadow-glow-blue px-8 h-12 text-sm font-medium"
            >
              Book a Merchant Demo
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => startLogin()}
              className="border-[var(--color-ts-border-light)] text-[var(--color-ts-muted)] hover:text-white hover:border-white/30 h-12 px-8 text-sm"
            >
              Experience Try-On
            </Button>
          </div>

          <div className="flex items-center gap-6 pt-2">
            {[["2.4×", "Conversion lift"], ["68%", "Return reduction"], ["< 5 min", "Setup time"]].map(([stat, label]) => (
              <div key={label} className="text-center">
                <div className="font-serif text-2xl font-semibold text-white">{stat}</div>
                <div className="text-xs text-[var(--color-ts-muted)] mt-0.5">{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right — animated mannequin */}
        <div className="relative flex items-center justify-center">
          <div className="relative w-72 h-96 lg:w-80 lg:h-[28rem]">
            {/* Glow ring */}
            <div
              className="absolute inset-0 rounded-full blur-[60px] opacity-30 transition-colors duration-1000"
              style={{ backgroundColor: colors[activeColor] }}
            />
            {/* Mannequin body */}
            <div className="relative z-10 w-full h-full flex items-center justify-center">
              <svg viewBox="0 0 200 320" className="w-48 h-64 lg:w-56 lg:h-72 drop-shadow-2xl" fill="none">
                {/* Head */}
                <ellipse cx="100" cy="32" rx="22" ry="26" fill="oklch(0.20 0.008 260)" stroke="oklch(0.30 0.01 260)" strokeWidth="1" />
                {/* Neck */}
                <rect x="91" y="55" width="18" height="18" rx="4" fill="oklch(0.20 0.008 260)" />
                {/* Shoulders */}
                <path d="M55 73 Q100 65 145 73 L148 100 Q100 92 52 100 Z" fill={colors[activeColor]} opacity="0.9" className="transition-colors duration-1000" />
                {/* Torso / garment */}
                <rect x="60" y="98" width="80" height="90" rx="6"
                  fill={colors[activeColor]}
                  opacity="0.85"
                  className="transition-colors duration-1000"
                />
                {/* Collar detail */}
                <path d="M85 73 L100 90 L115 73" stroke="oklch(0.85 0.01 260)" strokeWidth="1.5" fill="none" opacity="0.6" />
                {/* Left arm */}
                <path d="M60 100 Q42 120 44 160 L56 158 Q56 122 72 104 Z"
                  fill={colors[activeColor]} opacity="0.75" className="transition-colors duration-1000" />
                {/* Right arm */}
                <path d="M140 100 Q158 120 156 160 L144 158 Q144 122 128 104 Z"
                  fill={colors[activeColor]} opacity="0.75" className="transition-colors duration-1000" />
                {/* Pants */}
                <rect x="62" y="185" width="34" height="100" rx="4" fill="oklch(0.18 0.008 260)" stroke="oklch(0.28 0.01 260)" strokeWidth="1" />
                <rect x="104" y="185" width="34" height="100" rx="4" fill="oklch(0.18 0.008 260)" stroke="oklch(0.28 0.01 260)" strokeWidth="1" />
                {/* Waistband */}
                <rect x="60" y="183" width="80" height="10" rx="3" fill="oklch(0.22 0.008 260)" />
                {/* Shoes */}
                <ellipse cx="79" cy="292" rx="20" ry="8" fill="oklch(0.14 0.005 260)" />
                <ellipse cx="121" cy="292" rx="20" ry="8" fill="oklch(0.14 0.005 260)" />
              </svg>
            </div>

            {/* Color selector chips */}
            <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
              {colors.map((c, i) => (
                <button
                  key={c}
                  onClick={() => setActiveColor(i)}
                  className={cn(
                    "w-5 h-5 rounded-full border-2 transition-all duration-200",
                    activeColor === i ? "border-white scale-110" : "border-transparent opacity-60"
                  )}
                  style={{ backgroundColor: c }}
                  title={colorNames[i]}
                />
              ))}
            </div>
          </div>

          {/* Floating cards */}
          <div className="absolute top-4 -left-4 lg:-left-12 bg-glass rounded-xl p-3 shadow-elevated animate-float">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[var(--color-ts-blue)]/20 flex items-center justify-center">
                <TrendingUp className="w-3.5 h-3.5 text-[var(--color-ts-blue-light)]" />
              </div>
              <div>
                <div className="text-xs font-semibold text-white">+2.4× Sales</div>
                <div className="text-[10px] text-[var(--color-ts-muted)]">Conversion lift</div>
              </div>
            </div>
          </div>

          <div className="absolute top-1/3 -right-4 lg:-right-10 bg-glass rounded-xl p-3 shadow-elevated animate-float-delayed">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[var(--color-ts-violet)]/20 flex items-center justify-center">
                <Users className="w-3.5 h-3.5 text-[var(--color-ts-violet-light)]" />
              </div>
              <div>
                <div className="text-xs font-semibold text-white">1,240 Try-ons</div>
                <div className="text-[10px] text-[var(--color-ts-muted)]">This week</div>
              </div>
            </div>
          </div>

          <div className="absolute bottom-16 -right-4 lg:-right-12 bg-glass rounded-xl p-3 shadow-elevated animate-float" style={{ animationDelay: "1s" }}>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-green-500/20 flex items-center justify-center">
                <Check className="w-3.5 h-3.5 text-green-400" />
              </div>
              <div>
                <div className="text-xs font-semibold text-white">Size: M — Fits</div>
                <div className="text-[10px] text-[var(--color-ts-muted)]">AI recommendation</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll hint */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-[var(--color-ts-muted)]">
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <ChevronDown className="w-4 h-4 animate-bounce" />
      </div>
    </section>
  );
}

/* ─── Features ───────────────────────────────────────────────────────────── */
const FEATURES = [
  { icon: Wand2,      title: "AI-Powered Try-On",     desc: "Photorealistic garment rendering on real body shapes using advanced diffusion models." },
  { icon: Zap,        title: "5-Minute Setup",         desc: "Connect your Shopify store, import products, and go live in under five minutes." },
  { icon: BarChart3,  title: "Deep Analytics",         desc: "Track every try-on session, conversion event, and top-performing garment in real time." },
  { icon: ShoppingBag,title: "Cart Integration",       desc: "Seamless add-to-cart handoff from the try-on widget directly to your checkout flow." },
  { icon: Shield,     title: "Privacy First",          desc: "Shopper photos are processed ephemerally and never stored without explicit consent." },
  { icon: Plug,       title: "Platform Agnostic",      desc: "Native integrations for Shopify, WooCommerce, and a REST API for custom storefronts." },
];

function Features() {
  return (
    <section id="features" className="py-28 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,oklch(0.12_0.01_260)_0%,transparent_70%)]" />
      <div className="container relative z-10">
        <div className="text-center mb-16 space-y-4">
          <Badge className="bg-[var(--color-ts-violet)]/10 text-[var(--color-ts-violet-light)] border-[var(--color-ts-violet)]/20 text-xs">
            Platform Features
          </Badge>
          <h2 className="font-serif text-4xl lg:text-5xl font-light text-white">
            Everything a modern fashion retailer needs
          </h2>
          <p className="text-[var(--color-ts-muted)] max-w-xl mx-auto">
            From AI rendering to analytics, Trendset is the complete virtual try-on infrastructure for your store.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map(({ icon: Icon, title, desc }) => (
            <div
              key={title}
              className="group bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-6 hover:border-[var(--color-ts-blue)]/30 hover:bg-[var(--color-ts-surface-2)] transition-all duration-300 shadow-card"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-brand/10 border border-[var(--color-ts-blue)]/20 flex items-center justify-center mb-4 group-hover:shadow-glow-blue transition-all duration-300">
                <Icon className="w-5 h-5 text-[var(--color-ts-blue-light)]" />
              </div>
              <h3 className="font-serif text-lg font-medium text-white mb-2">{title}</h3>
              <p className="text-sm text-[var(--color-ts-muted)] leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── How It Works ───────────────────────────────────────────────────────── */
const STEPS = [
  { n: "01", title: "Connect Your Store",   desc: "Authenticate with Shopify or WooCommerce in one click. Your product catalog syncs automatically." },
  { n: "02", title: "Activate Try-On",      desc: "Select which products get the try-on widget. Configure appearance to match your brand in minutes." },
  { n: "03", title: "Watch Conversions Grow", desc: "Shoppers try on garments instantly. You collect analytics, reduce returns, and grow revenue." },
];

function HowItWorks() {
  return (
    <section id="how-it-works" className="py-28">
      <div className="container">
        <div className="text-center mb-16 space-y-4">
          <Badge className="bg-[var(--color-ts-blue)]/10 text-[var(--color-ts-blue-light)] border-[var(--color-ts-blue)]/20 text-xs">
            How It Works
          </Badge>
          <h2 className="font-serif text-4xl lg:text-5xl font-light text-white">
            Live in three steps
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connector line */}
          <div className="hidden md:block absolute top-8 left-[calc(16.67%+1rem)] right-[calc(16.67%+1rem)] h-px bg-gradient-to-r from-transparent via-[var(--color-ts-border)] to-transparent" />

          {STEPS.map(({ n, title, desc }) => (
            <div key={n} className="relative text-center space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-brand shadow-glow-blue mx-auto">
                <span className="font-serif text-2xl font-light text-white">{n}</span>
              </div>
              <h3 className="font-serif text-xl font-medium text-white">{title}</h3>
              <p className="text-sm text-[var(--color-ts-muted)] leading-relaxed max-w-xs mx-auto">{desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Pricing ────────────────────────────────────────────────────────────── */
const PLANS = [
  {
    name: "Pilot",
    price: "$49",
    period: "/month",
    desc: "Perfect for stores just getting started with virtual try-on.",
    features: ["Up to 500 try-on sessions/mo", "1 storefront", "Basic analytics", "Email support", "Shopify integration"],
    cta: "Start Pilot",
    highlighted: false,
  },
  {
    name: "Growth",
    price: "$149",
    period: "/month",
    desc: "For growing stores that need more sessions and deeper insights.",
    features: ["Up to 5,000 try-on sessions/mo", "3 storefronts", "Advanced analytics", "Priority support", "All integrations", "Custom widget branding"],
    cta: "Start Growth",
    highlighted: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "",
    desc: "Tailored plans for high-volume retailers and multi-brand groups.",
    features: ["Unlimited try-on sessions", "Unlimited storefronts", "Dedicated analytics", "Dedicated support", "SLA guarantee", "Custom AI model training"],
    cta: "Contact Sales",
    highlighted: false,
  },
];

function Pricing() {
  return (
    <section id="pricing" className="py-28 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,oklch(0.12_0.01_260)_0%,transparent_70%)]" />
      <div className="container relative z-10">
        <div className="text-center mb-16 space-y-4">
          <Badge className="bg-[var(--color-ts-violet)]/10 text-[var(--color-ts-violet-light)] border-[var(--color-ts-violet)]/20 text-xs">
            Pricing
          </Badge>
          <h2 className="font-serif text-4xl lg:text-5xl font-light text-white">
            Simple, transparent pricing
          </h2>
          <p className="text-[var(--color-ts-muted)] max-w-md mx-auto">
            Start free, scale as you grow. No hidden fees, no long-term contracts.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={cn(
                "relative rounded-2xl p-8 flex flex-col gap-6 transition-all duration-300",
                plan.highlighted
                  ? "bg-gradient-to-b from-[var(--color-ts-blue)]/20 to-[var(--color-ts-violet)]/10 border border-[var(--color-ts-blue)]/40 shadow-glow-blue"
                  : "bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] hover:border-[var(--color-ts-border-light)]"
              )}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-gradient-brand text-white border-0 text-xs px-3">Most Popular</Badge>
                </div>
              )}
              <div>
                <h3 className="font-serif text-xl font-medium text-white mb-1">{plan.name}</h3>
                <p className="text-xs text-[var(--color-ts-muted)]">{plan.desc}</p>
              </div>
              <div className="flex items-end gap-1">
                <span className="font-serif text-4xl font-light text-white">{plan.price}</span>
                <span className="text-sm text-[var(--color-ts-muted)] mb-1">{plan.period}</span>
              </div>
              <ul className="space-y-2.5 flex-1">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm text-[var(--color-ts-muted)]">
                    <Check className="w-4 h-4 text-[var(--color-ts-blue-light)] shrink-0 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>
              <Button
                onClick={() => startLogin()}
                className={cn(
                  "w-full h-10 text-sm font-medium",
                  plan.highlighted
                    ? "bg-gradient-brand text-white hover:opacity-90 shadow-glow-blue"
                    : "border border-[var(--color-ts-border-light)] text-[var(--color-ts-muted)] hover:text-white hover:border-white/30 bg-transparent"
                )}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Testimonials ───────────────────────────────────────────────────────── */
const TESTIMONIALS = [
  {
    quote: "Trendset reduced our return rate by 60% in the first month. The widget feels like a natural part of our store — shoppers love it.",
    name: "Aria Chen",
    role: "Founder, Lumière Boutique",
    rating: 5,
  },
  {
    quote: "Setup took literally four minutes. We connected Shopify, enabled try-on for our top 20 products, and saw a 2.1× lift in add-to-cart within a week.",
    name: "Marcus Webb",
    role: "Head of E-Commerce, Vela Studio",
    rating: 5,
  },
  {
    quote: "The analytics dashboard alone is worth it. We now know exactly which garments drive the most engagement and optimize our catalog accordingly.",
    name: "Sofia Reyes",
    role: "Digital Director, Maison Éclat",
    rating: 5,
  },
];

function Testimonials() {
  return (
    <section className="py-28">
      <div className="container">
        <div className="text-center mb-6 space-y-2">
          <p className="text-xs text-[var(--color-ts-muted)] tracking-widest uppercase">
            Illustrative merchant perspectives
          </p>
          <h2 className="font-serif text-4xl lg:text-5xl font-light text-white">
            Merchants love Trendset
          </h2>
        </div>
        <p className="text-center text-xs text-[var(--color-ts-muted-2)] mb-14 max-w-md mx-auto">
          The following quotes are illustrative examples of the merchant experience and do not represent verified customer testimonials.
        </p>

        <div className="grid md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.name}
              className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-2xl p-7 space-y-5 hover:border-[var(--color-ts-border-light)] transition-colors shadow-card"
            >
              <div className="flex gap-0.5">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[var(--color-ts-blue-light)] text-[var(--color-ts-blue-light)]" />
                ))}
              </div>
              <p className="text-sm text-[var(--color-foreground)] leading-relaxed italic font-serif">
                "{t.quote}"
              </p>
              <div>
                <div className="text-sm font-medium text-white">{t.name}</div>
                <div className="text-xs text-[var(--color-ts-muted)]">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── FAQ ────────────────────────────────────────────────────────────────── */
const FAQS = [
  { q: "How does the virtual try-on work?", a: "Trendset uses AI diffusion models to composite your garment images onto a shopper's photo or a model image, producing a photorealistic preview. The result is clearly labeled as a style visualization." },
  { q: "Does Trendset store shopper photos?", a: "No. By default, shopper photos are processed ephemerally and deleted immediately after the try-on is generated. Merchants can optionally enable saved looks with explicit shopper consent." },
  { q: "Which platforms does Trendset support?", a: "Trendset has native integrations for Shopify and WooCommerce, plus a REST API for custom storefronts. More platform integrations are on the roadmap." },
  { q: "How long does setup take?", a: "Most merchants go live in under five minutes. Connect your store, select products, customize the widget, and publish — that's it." },
  { q: "Can I customize the widget to match my brand?", a: "Yes. You can customize button text, colors, border radius, font, and placement. A live preview shows exactly how the widget will appear on your storefront." },
  { q: "What happens if I exceed my monthly session limit?", a: "On Pilot and Growth plans, additional sessions are billed at a per-session overage rate. Enterprise plans include unlimited sessions." },
];

function FAQ() {
  return (
    <section id="faq" className="py-28">
      <div className="container max-w-3xl">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-serif text-4xl lg:text-5xl font-light text-white">
            Frequently asked questions
          </h2>
        </div>
        <Accordion type="single" collapsible className="space-y-3">
          {FAQS.map((faq, i) => (
            <AccordionItem
              key={i}
              value={`faq-${i}`}
              className="bg-[var(--color-ts-surface)] border border-[var(--color-ts-border)] rounded-xl px-6 data-[state=open]:border-[var(--color-ts-blue)]/30"
            >
              <AccordionTrigger className="text-sm font-medium text-white hover:no-underline py-5 text-left">
                {faq.q}
              </AccordionTrigger>
              <AccordionContent className="text-sm text-[var(--color-ts-muted)] leading-relaxed pb-5">
                {faq.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}

/* ─── Final CTA ──────────────────────────────────────────────────────────── */
function FinalCTA() {
  return (
    <section className="py-28 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] rounded-full bg-[var(--color-ts-blue)]/10 blur-[100px]" />
      </div>
      <div className="container relative z-10 text-center space-y-8">
        <h2 className="font-serif text-5xl lg:text-6xl font-light text-white leading-tight">
          Give every shopper<br />
          <span className="text-gradient-blue italic">a fitting room.</span>
        </h2>
        <p className="text-lg text-[var(--color-ts-muted)] max-w-md mx-auto">
          Join forward-thinking fashion retailers already using Trendset to transform their online shopping experience.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4">
          <Button
            size="lg"
            onClick={() => startLogin()}
            className="bg-gradient-brand text-white hover:opacity-90 shadow-glow-blue px-10 h-13 text-sm font-medium"
          >
            Apply for Pilot
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => startLogin()}
            className="border-[var(--color-ts-border-light)] text-[var(--color-ts-muted)] hover:text-white h-13 px-10 text-sm"
          >
            Book Demo
          </Button>
        </div>
      </div>
    </section>
  );
}

/* ─── Footer ─────────────────────────────────────────────────────────────── */
function Footer() {
  return (
    <footer className="border-t border-[var(--color-ts-border)] py-12">
      <div className="container flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-gradient-brand flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="font-serif text-base font-semibold text-white">Trendset</span>
        </div>
        <p className="text-xs text-[var(--color-ts-muted)]">
          © {new Date().getFullYear()} Trendset. All rights reserved.
        </p>
        <div className="flex gap-6 text-xs text-[var(--color-ts-muted)]">
          <a href="#" className="hover:text-white transition-colors">Privacy</a>
          <a href="#" className="hover:text-white transition-colors">Terms</a>
          <a href="#" className="hover:text-white transition-colors">Contact</a>
        </div>
      </div>
    </footer>
  );
}

/* ─── Page ───────────────────────────────────────────────────────────────── */
export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[var(--color-background)] text-[var(--color-foreground)]">
      <Nav />
      <Hero />
      <Features />
      <HowItWorks />
      <Pricing />
      <Testimonials />
      <FAQ />
      <FinalCTA />
      <Footer />
    </div>
  );
}
