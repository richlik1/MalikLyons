import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the database
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
}));

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createCtx(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "demo-merchant",
    email: "demo@lumiere.com",
    name: "Demo Merchant",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("demo.analytics", () => {
  it("returns analytics summary with correct shape", async () => {
    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.demo.analytics();

    expect(result).toHaveProperty("totalSessions");
    expect(result).toHaveProperty("conversionRate");
    expect(result).toHaveProperty("revenueLift");
    expect(result).toHaveProperty("activeProducts");
    expect(result).toHaveProperty("topProducts");
    expect(Array.isArray(result.topProducts)).toBe(true);
    expect(result.totalSessions).toBeGreaterThan(0);
    expect(result.conversionRate).toBeGreaterThan(0);
  });

  it("returns top products with required fields", async () => {
    const ctx = createCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.demo.analytics();

    result.topProducts.forEach((p) => {
      expect(p).toHaveProperty("name");
      expect(p).toHaveProperty("sessions");
      expect(p).toHaveProperty("revenue");
      expect(typeof p.name).toBe("string");
      expect(typeof p.sessions).toBe("number");
    });
  });
});

describe("auth.logout", () => {
  it("clears session cookie", async () => {
    const ctx = createCtx();
    const cleared: string[] = [];
    ctx.res.clearCookie = (name: string) => { cleared.push(name); };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(cleared.length).toBe(1);
  });
});
